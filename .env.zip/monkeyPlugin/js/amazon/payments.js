{
    matchStart: function () {
        console.log("进入日期范围报告脚本");
        if ($('#DateRangeReportsView').length > 0) {
            var html = `
            <span id="zhizi_payments_standard_download" class="a-button a-button-primary a-declarative">
                <span class="a-button-inner">
                    <input class="a-button-input">
                    <span class="a-button-text" aria-hidden="true">生成并上传日期范围报告到ERP</span>
                </span>
            </span>
            <span id="set_auto_generate_report" class="a-button a-button-primary a-declarative">
                <span class="a-button-inner">
                    <input class="a-button-input">
                    <span class="a-button-text" aria-hidden="true">设置自动生成上传报告到ERP</span>
                </span>
            </span>
            `
            $('#drrGenerateReportDisplayableContent').append(html)
            $('.generateReports').css('width', '1500px')
            // 生成并上传日期范围报告到ERP按钮事件
            $('#zhizi_payments_standard_download').click(function() {
                ZhiziPaymentsAll.reportType = "AllPayments";
                ZhiziPaymentsAll.init();
            })
            // 设置自动生成上传报告到ERP按钮事件
            $('#set_auto_generate_report').click(function() {
                ZhiziPaymentsAll.initAuto();
            })
            // 初始化当前账号所有的站点
            ZhiziPaymentsAll.initAccountSite();
        } else {
            console.log('当前页面不是日期范围报告页面');
        }
    },
    init: function () {
        // 加载外部util中的js类
        ZhiziCommon.getUtilScript('/js/utils/DateUtil.js?v=' + 100, "DateUtil");
        ZhiziCommon.getUtilScript('/js/plugins/jquery.easyui.min.js?v=' + 100, "EasyUi");
        console.log("进入日期范围报告报告脚本 init");
        var ZhiziPaymentsAll = {
            reportType: "",
            site: "",
            account: "",
            dateRangeBegin: "",
            dateRangeEnd: "",
            logCnt: 0,
            symbol: "",
            logMessage: "执行日志:",
            refreshTimes: 0,
            reLoadSite: 0, // 轮询加载站点次数
            autoSetting: {}, // 自动配置设置参数
            amazonPaymentReportGenerateRequestHeader: {
                "host": window.location.host,
                "user-agent": navigator.userAgent,
                "accept": "*/*",
                "accept-language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
                "accept-encoding": "gzip, deflate, br",
                "Origin": "https://" + window.location.host,
                "referer": document.documentURI,
                "content-type": "application/json",
            },
            allSiteArr: [
                {
                    site: 'Japan', // 日本
                    id: 'A1VC38T7YXB528',
                    gmt: 8
                },
                {
                    site: 'Singapore', // 新加坡
                    id: 'A19VAU5U5O7RUS',
                    gmt: 7
                },
                {
                    site: 'Germany', // 德国
                    id: 'A1PA6795UKMFR9',
                    gmt: 1
                },
                {
                    site: 'France', // 法国
                    id: 'A13V1IB3VIYZZH',
                    gmt: 1
                },
                {
                    site: 'Italy', // 意大利
                    id: 'APJ6JRA9NG5V4',
                    gmt: 1
                },
                {
                    site: 'United Kingdom', // 英国
                    id: 'A1F83G8C2ARO7P',
                    gmt: 0
                },
                {
                    site: 'Mexico', // 墨西哥站点英文名
                    id: 'A1AM78C64UM0Y8', // 对应dom的ID
                    gmt: -5 // 站点时差 每天下午一点 就是新的一天了
                },
                {
                    site: 'Canada', // 加拿大
                    id: 'A2EUQ1WTGCTBG2',
                    gmt: -8 // 下午三点就是新的一天
                },
                {
                    site: 'United States', // 美国
                    id: 'ATVPDKIKX0DER',
                    gmt: -8 // 下午三点就是新的一天
                }
            ],
            // 我们的需要自动生成上传的站点数据
            siteArr: [],
            // 轮循
            timer: null,
            autoDone: false, // 自动生成处理中状态
            halfStop: false, // 是否中途停止自动上传状态
            // 初始化生成自动生成配置
            initAuto: function() {
                if ($.fn.combotree) {
                    ZhiziCommon.openMask();
                    ZhiziCommon.setMaskTitle('设置每天自动生成并上传日期范围报告到ERP系统');
                    if (!ZhiziCommon.isEnglish()) {
                        ZhiziCommon.setMaskFoot('请把语言设置为英文(Please change language to English)');
                        ZhiziCommon.showCloseBtn();
                        return;
                    }
                    ZhiziPaymentsAll.getAccountSite();
                } else {
                    alert('插件数据正在加载处理，请稍后再打开~');
                }
            },
            // 上传完成后触发事件-用于判断是否还有下一个站点需要继续自动生成
            uploadDoneHandler: function() {
                let siteDrop = $('.merchant-level li');
                $.each(siteDrop, (index, item)=>{
                    ZhiziPaymentsAll.siteArr.forEach(async (site, idx) => {
                        try {
                            if (item.childNodes[0].getAttribute('class') === 'currentSelection' && item.childNodes[0].innerHTML === site.site) {
                                if (idx + 1 > ZhiziPaymentsAll.siteArr.length - 1) { // 表示所有站点已经处理完成了
                                    ZhiziPaymentsAll.autoSetting.completeStatus = true
                                    await ZhiziCommon.request({
                                        method: "POST",
                                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                                        url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                                        data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(ZhiziPaymentsAll.autoSetting)}`
                                    })
                                    ZhiziCommon.setMaskTitle(`${ ZhiziCommon.getDateString(new Date()) }已完成今天所有站点的日期范围报告生成并且上传到ERP，请到ERP系统查看！`);
                                    ZhiziCommon.showCloseBtn();
                                    ZhiziPaymentsAll.autoDone = false;
                                    return;
                                } else { // 否则就是还有站点没处理，需要跳到下一站点继续处理
                                    ZhiziPaymentsAll.autoSetting.currentSoluSite = ZhiziPaymentsAll.siteArr[idx+1].site
                                    ZhiziPaymentsAll.autoSetting.isJump = true
                                    await ZhiziCommon.request({
                                        method: "POST",
                                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                                        url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                                        data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(ZhiziPaymentsAll.autoSetting)}`
                                    })
                                    $(`#${ ZhiziPaymentsAll.siteArr[idx+1].id }`)[0].click(); // 跳转到下一个站点
                                }
                            }
                        } catch (error) {
                            console.log('上传完成函数=>', error)
                            setTimeout(function() {
                                location.reload()
                            }, 300000)
                        }
                    })
                })
            },
            // 自动生成轮循处理
            autoCheckHandler: async function() {
                try {
                    if (ZhiziPaymentsAll.autoSetting.prevDate !== ZhiziCommon.getDateString(new Date())) { // 如果当前日期跟本地存储日期不一样 那证明就是第二天了
                        console.log('第二天了，需要重置一下数据了', ZhiziCommon.getDateString(new Date()));
                        ZhiziPaymentsAll.autoSetting.prevDate = ZhiziCommon.getDateString(new Date());
                        ZhiziPaymentsAll.autoSetting.currentSoluSite = ZhiziPaymentsAll.siteArr[0].site;
                        ZhiziPaymentsAll.autoSetting.completeStatus = false;
                        await ZhiziCommon.request({
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                            data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(ZhiziPaymentsAll.autoSetting)}`
                        })
                    }
                    if (ZhiziPaymentsAll.autoSetting.dateReport && ZhiziPaymentsAll.autoSetting.dateReport.autoOpen === 'off' || !ZhiziPaymentsAll.autoSetting.dateReport || !ZhiziPaymentsAll.autoSetting.dateReport.autoOpen) { // 自动开关处于关闭状态
                        console.log('自动正处于关闭状态，停止执行');
                        clearInterval(ZhiziPaymentsAll.timer);
                        return;
                    }
                    // && new Date().getHours() >= 12 && new Date().getHours() <= 18
                    if (ZhiziPaymentsAll.autoSetting.dateReport && ZhiziPaymentsAll.autoSetting.dateReport.autoOpen === 'on' && !ZhiziPaymentsAll.autoSetting.completeStatus && !ZhiziPaymentsAll.autoDone) { // 自动生成开启状态且还没完成所有状态且12点-6点
                        for (let i = 0; i < ZhiziPaymentsAll.siteArr.length; i++) {
                            if (ZhiziPaymentsAll.siteArr[i].site === ZhiziPaymentsAll.autoSetting.currentSoluSite) { // 根据不同站点不同时区 在站点新的一天时候 开始自动上传数据
                                let time = ZhiziPaymentsAll.formatTimeZone(new Date(), ZhiziPaymentsAll.siteArr[i].gmt); // ZhiziPaymentsAll.siteArr[i].gmt
                                let hours = time.getHours(); // 取出站点当前小时
                                let chinaDay = new Date().getDate(); // 取出中国当前日期
                                let siteDay = time.getDate(); // 取出站点当前日期
                                if (hours >= 0 && chinaDay === siteDay) { // 就是每天的凌晨12点且站点日期等于中国当前的日期 那就证明站点已经是在另一天了 可以开始生成数据了
                                    let currentSite = $('.currentSelection').text(); // 获取当前站点
                                    let reportTable = document.getElementById('daterangereportstable');
                                    if (!currentSite || !reportTable) {
                                        ZhiziPaymentsAll.reLoadSite = ZhiziPaymentsAll.reLoadSite + 1
                                        if (ZhiziPaymentsAll.reLoadSite >= 240) {
                                            console.log('站点一直没出来，重新刷新加载吧~');
                                            location.reload()
                                            return
                                        }
                                        console.log('页面站点还没加载出来，已终止后续操作，等待第二次轮询');
                                        return
                                    }
                                    if (!ZhiziCommon.isEnglish()) { // 如果页面不是英文环境就自动帮他切换到英文状态
                                        clearInterval(ZhiziPaymentsAll.timer);
                                        $("#sc-lang-switcher-header-select option[selected=selected]").removeAttr('selected'); // 先把当前选中的语言去掉
                                        $("#sc-lang-switcher-header-select option[value^=en_]").attr('selected', 'selected'); // 然后再选中语言英文
                                        $("#sc-lang-switcher-header-select option[value^=en_]").trigger("change"); // 最后触发事件让它切换
                                        return;
                                    }
                                    if (ZhiziPaymentsAll.autoSetting.currentSoluSite && ZhiziPaymentsAll.autoSetting.currentSoluSite !== currentSite) { // 当前页面不在当前处理站点时，就让他跳到处理的站点页面
                                        console.log('当前站点：' + currentSite, '当前需要处理站点：' + ZhiziPaymentsAll.autoSetting.currentSoluSite, '检测到站点不一样，正在跳转');
                                        ZhiziPaymentsAll.siteArr.forEach(async (item, idx) => {
                                            try {
                                                if (item.site === ZhiziPaymentsAll.autoSetting.currentSoluSite) {
                                                    clearInterval(ZhiziPaymentsAll.timer);
                                                    ZhiziPaymentsAll.autoSetting.isJump = true
                                                    await ZhiziCommon.request({
                                                        method: "POST",
                                                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                                                        url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                                                        data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(ZhiziPaymentsAll.autoSetting)}`
                                                    })
                                                    $(`#${ZhiziPaymentsAll.siteArr[idx].id}`)[0].click()
                                                    return;
                                                }
                                            } catch (error) {
                                                console.log('站点跳转处理=>', error)
                                                setTimeout(function() {
                                                    location.reload()
                                                }, 300000)
                                            }
                                        })
                                    }
                                    // 获取账号和站点
                                    ZhiziPaymentsAll.site = ZhiziCommon.getCurrentSite();
                                    ZhiziPaymentsAll.account = ZhiziCommon.getAccount().toLocaleLowerCase();
                                    if (ZhiziPaymentsAll.site.length == 0 || ZhiziPaymentsAll.account.length == 0) {
                                        console.log('获取账号与站点失败！');
                                        return;
                                    }
                                    if (!ZhiziPaymentsAll.autoDone && ZhiziPaymentsAll.autoSetting.currentSoluSite === currentSite) {
                                        ZhiziPaymentsAll.autoDone = true;
                                        console.log('开始生成上传...');
                                        ZhiziPaymentsAll.autoCatchHandler();
                                    }
                                }
                                break;  
                            }
                        }
                    }
                } catch (error) {
                    console.log('自动生成轮循=>' ,error)
                    setTimeout(function() {
                        location.reload()
                    }, 300000)
                }
            },
            // 开始自动生成上传事件
            autoCatchHandler: function() {
                if ($('#DateRangeReportsView').length > 0) { // 判断下当前是否在日期范围报告生成页面
                    ZhiziCommon.openMask();
                    ZhiziPaymentsAll.dateRangeBegin = zhiziDataUtil.getBeforeDate(
                        ZhiziPaymentsAll.autoSetting.dateReport.generateDate  === '1' ? 2 :
                        ZhiziPaymentsAll.autoSetting.dateReport.generateDate === '3' ? 3 :
                        ZhiziPaymentsAll.autoSetting.dateReport.generateDate === '7' ? 7 : 31
                        // ZhiziCommon.getItem('dateReport').generateDate === '1' ? 2 :
                        // ZhiziCommon.getItem('dateReport').generateDate === '3' ? 3 :
                        // ZhiziCommon.getItem('dateReport').generateDate === '7' ? 7 : 31
                    );
                    ZhiziPaymentsAll.dateRangeEnd = ZhiziCommon.getDateString(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() - 1)); // 1
                    var bd = ZhiziPaymentsAll.dateRangeBegin.split("-");
                    var ed = ZhiziPaymentsAll.dateRangeEnd.split("-");
                    if (bd.length != 3 || ed.length != 3) {
                        alert('手动输入的时间格式应该是：yyyy-mm-dd');
                        ZhiziCommon.setMaskFoot('手动输入的时间格式应该是：yyyy-mm-dd');
                        ZhiziCommon.showCloseBtn();
                        ZhiziPaymentsAll.autoDone = false;
                        return;
                    }
                    ZhiziPaymentsAll.reportType = ZhiziPaymentsAll.autoSetting.dateReport.generateType
                    ZhiziCommon.setMaskTitle('正在自动生成且上传日期范围报告到ERP，类型：' + ZhiziPaymentsAll.reportType === 'AllSummary' ? '汇总': '交易' + ', 账号:' + ZhiziPaymentsAll.account + ", 站点：" + ZhiziPaymentsAll.site);
                    // 此处判别数据报告的类型 Transaction  OR Summary
                    var reportType = "";
                    if (ZhiziPaymentsAll.reportType == "AllSummary") {
                        reportType = "Summary";
                    } else if (ZhiziPaymentsAll.reportType == "AllPayments") {
                        reportType = "Transaction";
                    } else {
                        ZhiziPaymentsAll.autoDone = false;
                        alert("数据报告的类型选择错误,请重试。。。。");
                        return;
                    }
                    var jsonData = {
                        "reportType": reportType,
                        "timeRangeType": "Custom",
                        "startDate": {
                            "date": parseInt(bd[2]),
                            "month": parseInt(bd[1]),
                            "year": parseInt(bd[0])
                        },
                        "endDate": {
                            "date": parseInt(ed[2]),
                            "month": parseInt(ed[1]),
                            "year": parseInt(ed[0])
                        }
                    };
                    // US   IN   BR,只有此三个站点，有stand和invoice的报告，
                    // 只有all的选项,生成amazon的要加上此参数
                    if (ZhiziPaymentsAll.site == "www.amazon.com" ||
                        ZhiziPaymentsAll.site == "www.amazon.com.br" ||
                        ZhiziPaymentsAll.site == "www.amazon.in") {
                        jsonData.selectedAccountTypeDropdownValue = "All";
                    }
                    const csrfToken = $('#DateRangeReportsView meta[name=csrf-token]').attr('content')
                    ZhiziPaymentsAll.amazonPaymentReportGenerateRequestHeader['anti-csrftoken-a2z'] = csrfToken || ''
                    ZhiziPaymentsAll.generateReport(jsonData);
                } else {
                    ZhiziCommon.setMaskFoot('非生成DateRangePayments报告页面...');
                    ZhiziCommon.showCloseBtn();
                    ZhiziPaymentsAll.autoDone = false;
                    return;
                }
            },
            // 获取当前账号下的所有站点
            async getAccountSite() {
                ZhiziPaymentsAll.siteArr = [];
                // let dateReport = ZhiziPaymentsAll.autoSetting.dateReport
                // let dateReport = ZhiziCommon.getItem('dateReport');
                ZhiziCommon.setMaskBody("正在加载数据中，请稍等...");
                const res = await ZhiziCommon.request({
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/getAvailableSiteInfo',
                    data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}`
                });
                const siteInfo = JSON.parse(res.data.siteInfo);
                ZhiziPaymentsAll.allSiteArr.forEach(site => {
                    $.each(res.data.country, (index, item) => {
                        if (site.site === item) {
                            ZhiziPaymentsAll.siteArr.push({...site, text: site.site});
                        }
                    })
                });
                if (siteInfo.dateReport.autoSite) { // 如果之前已经设置过自动的站点，那就让他回显出来
                    ZhiziPaymentsAll.siteArr.forEach(site => {
                        siteInfo.dateReport.autoSite.forEach(autoSite => {
                            if (site.site === autoSite.site) {
                                site.checked = true;
                            }
                        })
                    })
                }
                ZhiziCommon.setMaskBody('<span>自动生成前<select id="beforeDay">' +
                    `<option value="1" ${ siteInfo.dateReport.generateDate === '1' ? 'selected' : '' }>1</option>` +
                    `<option value="3" ${ siteInfo.dateReport.generateDate === '3' ? 'selected' : '' }>3</option>` +
                    `<option value="7" ${ siteInfo.dateReport.generateDate === '7' ? 'selected' : '' }>7</option>` +
                    `<option value="0" ${ siteInfo.dateReport.generateDate === '0' ? 'selected' : '' }>31</option>` +
                    '</select>天</span>' +
                    '<div style="margin-top:30px;">' +
                    '<span>生成类型：</span>' +
                    `<input type="radio" name="autoReportType" value="AllPayments" ${ siteInfo.dateReport.generateType === 'AllPayments' ? 'checked' : '' } /><label for="AllPayments" style="display:inline-block">交易</label>&nbsp;` +
                    `<input type="radio" name="autoReportType" value="AllSummary" ${ siteInfo.dateReport.generateType === 'AllSummary' ? 'checked' : '' } /><label for="AllSummary" style="display:inline-block">汇总</label></br>` +
                    '<span>自动开关：</span>' + 
                    `<input type="radio" name="autoOpen" value="on" ${ siteInfo.dateReport.autoOpen === 'on' ? 'checked' : '' } /><label for="on" style="display:inline-block">开</label>&nbsp;` +
                    `<input type="radio" name="autoOpen" value="off" ${ siteInfo.dateReport.autoOpen === 'off' ? 'checked' : '' } /><label for="off" style="display:inline-block">关</label></br>` +
                    '<span>自动站点：</span>' +
                    '<select id="ddlLine" class="easyui-combotree" style="width: 205px; height: 24px;">' + 
                    '</div>'
                );
                ZhiziCommon.setMaskFoot('<button style="background-color: #00BCB4;border: 2px solid #00BCB4;margin:10pxcolor:#FFF;width:100px;" id="saveAutoHandler">保存配置</button>');
                ZhiziCommon.showCloseBtn();
                $('#ddlLine').combotree({
                    valueField: "id", //Value字段
                    textField: "text", //Text字段
                    multiple: true,
                    data: [{ "id": 1, "text": "All", "children": ZhiziPaymentsAll.siteArr }],
                    //                url: "tree_data2.json", //数据源
                    onCheck: function (node, checked) {
                        //让全选不显示
                        $("#ddlLine").combotree("setText", $("#ddlLine").combobox("getText").toString().replace("全选,", ""));
                    },
                    onClick: function (node, checked) {
                        //让全选不显示
                        $("#ddlLine").combotree("setText", $("#ddlLine").combobox("getText").toString().replace("全选,", ""));
                    },
                    onSelect: function (res) {
                        console.log(res)
                    },
                    onUnselect: function (res) {
                        console.log(res)
                    }
                });
                $('#saveAutoHandler').click(async function () {
                    try {
                        console.log('保存设置');
                        var t = $('#ddlLine').combotree('tree');	// get the tree object
                        var n = t.tree('getChecked');		// get selected node
                        var autoSite = []
                        if (n.length > 0) {
                            n.forEach(checked => {
                                if (checked.site) {
                                    autoSite.push({
                                        site: checked.site,
                                        id: checked.id,
                                        gmt: checked.gmt
                                    })
                                }
                            })
                        }
                        let generateDate = $("#beforeDay  option:selected").val(); // 获取选中的日期
                        let generateType = $('input:radio[name="autoReportType"]:checked').val(); // 获取选择生成报告的类型
                        let autoOpen = $('input:radio[name="autoOpen"]:checked').val(); // 获取选择生成报告的类型
                        if (!beforeDay) {
                            ZhiziCommon.setMaskFoot('请选择需要自动生成天数');
                            return;
                        } else if (!generateType) {
                            ZhiziCommon.setMaskFoot('请选择生成的报告类型');
                            return;
                        } else if (!autoOpen) {
                            ZhiziCommon.setMaskFoot('请选择是否开启自动生成报告');
                            return;
                        }
                        const params = ZhiziCommon.deepClone(ZhiziPaymentsAll.autoSetting);
                        params.dateReport.generateDate = generateDate;
                        params.dateReport.generateType = generateType;
                        params.dateReport.autoOpen = autoOpen;
                        params.dateReport.autoSite = autoSite;
                        params.prevDate = ZhiziCommon.getDateString(new Date());
                        params.currentSoluSite = ZhiziPaymentsAll.siteArr[0].site;
                        params.completeStatus = false;
                        await ZhiziCommon.request({
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                            data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(params)}`
                        })
                        ZhiziPaymentsAll.autoSetting = params
                        ZhiziCommon.closeMask();
                        clearInterval(ZhiziPaymentsAll.timer)
                        ZhiziPaymentsAll.timer = setInterval(ZhiziPaymentsAll.autoCheckHandler, 1000);
                    } catch (error) {
                       console.log('报错设置异常=>', error) 
                    }
                });
            },
            // 初次进入页面初始化站点
            async initAccountSite() {
                try {
                    ZhiziPaymentsAll.siteArr = [];
                    // 获取当前账号
                    let account = ZhiziCommon.getAccount().toLocaleLowerCase()
                    if (!account) {
                        ZhiziPaymentsAll.reLoadSite = ZhiziPaymentsAll.reLoadSite + 1
                        if (ZhiziPaymentsAll.reLoadSite >= 240) {
                            location.reload()
                            return
                        }
                        // 轮询取数据
                        setTimeout(() => {
                            ZhiziPaymentsAll.initAccountSite()
                        }, 2000)
                        return
                    }
                    // 获取当前站点
                    let currentSite = $('.currentSelection').text(); // 获取当前站点
                    if (!currentSite) {
                        ZhiziPaymentsAll.reLoadSite = ZhiziPaymentsAll.reLoadSite + 1
                        if (ZhiziPaymentsAll.reLoadSite >= 240) {
                            console.log('站点一直没出来，重新刷新加载吧~');
                            location.reload()
                            return
                        }
                        // 轮询取数据
                        setTimeout(() => {
                            ZhiziPaymentsAll.initAccountSite()
                            console.log('页面站点还没加载出来，已终止后续操作，等待第二次轮询');
                        }, 2000)
                        return
                    }
                    ZhiziPaymentsAll.reLoadSite = 0
                    const res = await ZhiziCommon.request({
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/getAvailableSiteInfo',
                        data: `account=${account}`
                    })
                    if (!res.data) {
                        alert('博创智光ERP机器人：' + res.msg)
                        return
                    }
                    ZhiziPaymentsAll.allSiteArr.forEach(site => {
                        $.each(res.data.country, (index, item) => {
                            if (site.site === item) {
                                ZhiziPaymentsAll.siteArr.push({...site, text: site.site});
                            }
                        })
                    })
                    console.log('获取站点：',ZhiziPaymentsAll.siteArr)
                    var siteInfo = {}
                    if (res.data.siteInfo) { // 已经有保存过自动配置数据
                        siteInfo = JSON.parse(res.data.siteInfo);
                        if (!siteInfo.currentSoluSite) {
                            console.log('当前处理站点不存在，默认设置一个站点');
                            siteInfo.currentSoluSite = ZhiziPaymentsAll.siteArr[0].site
                        }
                        // 当前处理站点等于当前所在的站点 就可以重置原本跳转状态
                        if (currentSite === siteInfo.currentSoluSite && siteInfo.isJump) {
                            siteInfo.isJump = false
                        }
                        if (siteInfo.prevDate !== ZhiziCommon.getDateString(new Date())) { // 如果当前日期跟本地存储日期不一样 那证明就是第二天了
                            console.log('第二天了，需要重置一下数据了', ZhiziCommon.getDateString(new Date()));
                            siteInfo.prevDate = ZhiziCommon.getDateString(new Date())
                            siteInfo.currentSoluSite = ZhiziPaymentsAll.siteArr[0].site
                            siteInfo.completeStatus = false
                        }
                        if (!siteInfo.dateReport) {
                            siteInfo.dateReport = {
                                generateDate: '1',
                                generateType: 'AllPayments',
                                autoOpen: 'off'
                            }
                            siteInfo.completeStatus = false
                        }
                        console.log('已设置过自动参数数据', siteInfo);
                        await ZhiziCommon.request({
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                            data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(siteInfo)}`
                        })
                        ZhiziPaymentsAll.autoSetting = ZhiziCommon.deepClone(siteInfo)
                        setTimeout(function() {
                            ZhiziPaymentsAll.timer = setInterval(ZhiziPaymentsAll.autoCheckHandler, 1000)
                        }, 5000)
                    } else {
                        siteInfo.currentSoluSite = ZhiziPaymentsAll.siteArr[0].site
                        siteInfo.prevDate = ZhiziCommon.getDateString(new Date())
                        siteInfo.currentSoluSite = ZhiziPaymentsAll.siteArr[0].site
                        siteInfo.isJump = false
                        siteInfo.dateReport = {
                            generateDate: '1',
                            generateType: 'AllPayments',
                            autoOpen: 'off'
                        }
                        siteInfo.completeStatus = false
                        console.log('首次设置自动数据', siteInfo);
                        await ZhiziCommon.request({
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/saveDateRangeSiteInfo',
                            data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}&siteInfo=${JSON.stringify(siteInfo)}`
                        })
                        ZhiziPaymentsAll.autoSetting = ZhiziCommon.deepClone(siteInfo)
                        setTimeout(function() {
                            ZhiziPaymentsAll.timer = setInterval(ZhiziPaymentsAll.autoCheckHandler, 1000)
                        }, 5000)
                    }
                } catch (error) {
                    console.log(error);
                    setTimeout(function() {
                        location.reload()
                    }, 300000)
                }
            },
            // 时间根据时区取时间
            formatTimeZone: function(time, offset) {
                var d = new Date(time); // 创建一个Date对象 time时间 offset 时区 中国为 8
                var localTime = d.getTime(); //获取的是毫秒级
                var localOffset = d.getTimezoneOffset() * 60000; // 获得当地时间偏移的毫秒数,时区是以分钟为单位的
                var utc = localTime + localOffset; // utc即GMT时间,世界时,格林威治时间
                var wishTime= utc + (3600000 * offset);
                return new Date(wishTime);
            },
            init: function () {
                console.log("-----按钮的全局的type类型--------------" + ZhiziPaymentsAll.reportType)
                if ($('#drrGenerateReportButton').length > 0) {
                    ZhiziCommon.openMask();
                    ZhiziPaymentsAll.queryLastestDate();
                } else {
                    alert('请手动切到Date Range Reports页面再点击采集');
                }
            },
            showDateRangeDialog: function () {
                ZhiziCommon.setMaskTitle('类型 ' + ZhiziPaymentsAll.reportType === 'AllSummary' ? '汇总': '交易' + ', 账号:' + ZhiziPaymentsAll.account + ", 站点：" + ZhiziPaymentsAll.site);
                ZhiziCommon.setMaskFoot(ZhiziPaymentsAll.summaryHtml());
                //监听 上个月日期  和 自定义时间的切换
                ZhiziPaymentsAll.defaultDataSelect(); //默认选择上个月
                $('input[name="specifyData"]').click(function () {
                    ZhiziPaymentsAll.defaultDataSelect();
                });
                // 选择生成报告的类型
                $('input[name="ReportType"]').click(function() {
                    var val = $('input:radio[name="ReportType"]:checked').val();
                    if (val === 'paymentsReport') {
                        ZhiziPaymentsAll.reportType = "AllPayments";
                    } else if (val === 'summaryReport') {
                        ZhiziPaymentsAll.reportType = "AllSummary";
                    }
                    ZhiziPaymentsAll.showLog("账号:" + ZhiziPaymentsAll.account);
                    ZhiziCommon.setMaskTitle('类型 ' + (ZhiziPaymentsAll.reportType === 'AllSummary' ? '汇总': '交易') + ', 账号:' + ZhiziPaymentsAll.account + ", 站点：" + ZhiziPaymentsAll.site);
                })
                //监听“开始”按钮
                $('#zhizi_custom_catch').click(function () {
                    ZhiziPaymentsAll.startCatch();
                    ZhiziCommon.hideCloseBtn()
                });
                ZhiziCommon.showCloseBtn();
            },
            defaultDataSelect: function () { //默认时间日期的选择
                var val = $('input:radio[name="specifyData"]:checked').val();
                if (val == "lastMonth") { //上个月
                    var firstdate = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
                    var date = new Date();
                    var day = new Date(date.getFullYear(), date.getMonth(), 0).getDate();
                    var enddate = new Date(new Date().getFullYear(), new Date().getMonth() - 1, day);
                    var firstdateformat = ZhiziCommon.formatDate(firstdate, "yyyy-MM-dd");
                    var enddateformat = ZhiziCommon.formatDate(enddate, "yyyy-MM-dd");
                    //填入上个月的时间，并且禁用输入框
                    $("#zhizi_start_date").val(firstdateformat);
                    $("#zhizi_start_date").attr("disabled", "disabled");
                    $("#zhizi_end_date").val(enddateformat);
                    $("#zhizi_end_date").attr("disabled", "disabled");
                } else if (val == "selfDefinedTime") { //自定义时间
                    $("#zhizi_start_date").removeAttr("disabled");
                    $("#zhizi_end_date").removeAttr("disabled");
                    //获取昨天的时间
                    var yesterday = zhiziDataUtil.getBeforeDate(1);
                    $("#zhizi_end_date").val(yesterday);
                }
            },
            summaryHtml: function () { // summaryHtml 的html展示
                var html =
                    '<div style="margin-top:30px;">' +
                    '<input type="radio" name="ReportType" value="paymentsReport" id="paymentsReport" checked/><label for="paymentsReport" style="display:inline-block">交易</label>&nbsp;' +
                    '<input type="radio" name="ReportType" value="summaryReport" id="summaryReport"/><label for="summaryReport" style="display:inline-block">汇总</label>' +
                    '</div>' +
                    '<div>' +
                    '  <div>指定日期</div>' +
                    '<div><small>日期格式:yyyy/mm/dd，如果没有时间控件，手动输入日期格式为：yyyy-mm-dd</small></div>' +
                    '<div>' +
                    '<input type="radio" name="specifyData" value="lastMonth" id="lastMonth" checked/><label for="lastMonth" style="display:inline-block">选择上个月</label>&nbsp;' +
                    '<input type="radio" name="specifyData" value="selfDefinedTime" id="selfDefinedTime"/><label for="selfDefinedTime" style="display:inline-block">自定义时间</label>' +
                    '</div>' +
                    '  <div style="margin-top:10px;">开始日期：<input type="date" id="zhizi_start_date" value="' + ZhiziPaymentsAll.dateRangeBegin + '"></div>' +
                    '  <div style="margin-top:10px;">结束日期：<input type="date" id="zhizi_end_date">' +
                    '</div>' +
                    '<button style="background-color: #00BCB4;border: 2px solid #00BCB4;margin:10px;padding:10px;color:#FFF;width:100px;" id="zhizi_custom_catch">开始</button></div>';
                return html;
            },
            startCatch: function () {
                if ($('#DateRangeReportsView').length > 0) {
                    ZhiziPaymentsAll.dateRangeBegin = $('#zhizi_start_date').val();
                    ZhiziPaymentsAll.dateRangeEnd = $('#zhizi_end_date').val();
                    var bd = ZhiziPaymentsAll.dateRangeBegin.split("-");
                    var ed = ZhiziPaymentsAll.dateRangeEnd.split("-");
                    if (bd.length != 3 || ed.length != 3) {
                        alert('手动输入的时间格式应该是：yyyy-mm-dd');
                        ZhiziCommon.setMaskFoot('手动输入的时间格式应该是：yyyy-mm-dd');
                        ZhiziCommon.showCloseBtn();
                        return;
                    }
                    //此处判别数据报告的类型 Transaction  OR Summary
                    var reportType = "";
                    if (ZhiziPaymentsAll.reportType == "AllSummary") {
                        reportType = "Summary";
                    } else if (ZhiziPaymentsAll.reportType == "AllPayments") {
                        reportType = "Transaction";
                    } else {
                        alert("数据报告的类型选择错误,请重试。。。。");
                        return;
                    }
                    
                    var jsonData = {
                        "reportType": reportType,
                        "timeRangeType": "Custom",
                        // "selectedAccountTypeDropdownValue":"All",
                        "startDate": {
                            "date": parseInt(bd[2]),
                            "month": parseInt(bd[1]),
                            "year": parseInt(bd[0])
                        },
                        "endDate": {
                            "date": parseInt(ed[2]),
                            "month": parseInt(ed[1]),
                            "year": parseInt(ed[0])
                        }
                    };
                    // debugger;
                    // US   IN   BR,只有此三个站点，有stand和invoice的报告，
                    // 只有all的选项,生成amazon的要加上此参数
                    if (ZhiziPaymentsAll.site == "www.amazon.com" ||
                        ZhiziPaymentsAll.site == "www.amazon.com.br" ||
                        ZhiziPaymentsAll.site == "www.amazon.in") {
                        jsonData.selectedAccountTypeDropdownValue = "All";
                    }
                    const csrfToken = $('#DateRangeReportsView meta[name=csrf-token]').attr('content')
                    ZhiziPaymentsAll.amazonPaymentReportGenerateRequestHeader['anti-csrftoken-a2z'] = csrfToken || ''
                    ZhiziPaymentsAll.generateReport(jsonData);
                } else {
                    ZhiziCommon.setMaskFoot('非生成DateRangePayments报告页面...');
                    ZhiziCommon.showCloseBtn();
                    return;
                }
            },
            generateReport: function (jsonData) {
                var msg = "";
                ZhiziCommon.setMaskTitle('<br/>请求生成' + ZhiziPaymentsAll.reportType);
                ZhiziCommon.setMaskFoot("<br />" + msg + "<br /><br />" + navigator.userAgent);
                var data = JSON.stringify(jsonData);
                ZhiziPaymentsAll.showLog("请求Amazon生成" + ZhiziPaymentsAll.reportType + "报告，请求信息：" + data);

                var onabortexception = function (resp) {
                    ZhiziPaymentsAll.showLog("请求Amazon生成" + ZhiziPaymentsAll.reportType + "报告失败");
                    ZhiziCommon.showCloseBtn();
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                        location.reload()
                    }
                };
                var onerrorexception = function (resp) {
                    ZhiziPaymentsAll.showLog("请求Amazon生成" + ZhiziPaymentsAll.reportType + "报告失败");
                    ZhiziCommon.showCloseBtn();
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                        location.reload()
                    }
                };
                var ontimeoutexception = function (resp) {
                    ZhiziPaymentsAll.showLog("请求amazon无响应，请刷新重试" + ZhiziPaymentsAll.reportType);
                    ZhiziCommon.showCloseBtn();
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                        location.reload()
                    }
                };
                GM_xmlhttpRequest({
                    method: "POST",
                    url: "/payments/reports/custom/submit/generateReports",
                    headers: ZhiziPaymentsAll.amazonPaymentReportGenerateRequestHeader,
                    data: data,
                    timeout: 30000,
                    onload: function (res) {
                        if (res.status == 200) {
                            try {
                                var json = JSON.parse(res.responseText);
                            } catch (e) {
                                console.log("出现错误" + e);
                                var borwerVersion = navigator.userAgent;
                                var linkman = " 【技术人员】 ";
                                ZhiziPaymentsAll.showLog("当前浏览器版本:" + borwerVersion + "无法获取amazon报告，请联系" + linkman + "处理");
                                ZhiziCommon.showCloseBtn();
                                if (ZhiziPaymentsAll.autoDone) {
                                    ZhiziCommon.closeMask();
                                    ZhiziPaymentsAll.autoDone = false;
                                    location.reload()
                                }
                                return;
                            }
                            var json = JSON.parse(res.responseText);
                            // 避免json.body.status报错
                            if (json.body == undefined) {
                                json.body = "";
                            }
                            if (json.status === "SUCCESS" || json.body.status === "SUCCESS") {
                                ZhiziPaymentsAll.showLog(ZhiziPaymentsAll.reportType + "报告生成请求已成功发送");
                                ZhiziPaymentsAll.refreshReport();
                                return;
                            } else {
                                ZhiziPaymentsAll.showLog("amazon报告生成有误，错误信息：" + json.message);
                                return;
                            }
                        }
                        console.log('generateReport-Http status:' + res.status);
                        onerrorexception(res);
                    },
                    onabort: onabortexception,
                    onerror: onerrorexception,
                    ontimeout: ontimeoutexception
                });
            },
            refreshReport: function () {
                ZhiziCommon.setMaskTitle(ZhiziPaymentsAll.reportType + '报告下载状态刷新...（请不要关闭浏览器窗口，如有业务需求请重新打开一个浏览器窗口进行操作！！！）');
                ZhiziPaymentsAll.amazonPaymentReportGenerateRequestHeader.accept = "text/html, */*; q=0.01";
                var requestData = {
                    "action": "CUSTOM_REFRESH",
                    "pageNumber": 1,
                    "recordsPerPage": 10,
                    "sortOrder": "DESCENDING",
                    "tableId": "daterangereportstable",
                    "filters": [],
                    "clientState": {}
                };
                var exception = function (res) {
                    ZhiziPaymentsAll.showLog("请求Amazon刷新" + ZhiziPaymentsAll.reportType + "报告状态失败");
                    ZhiziCommon.showCloseBtn();
                    ZhiziPaymentsAll.refreshTimes = 0
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                    }
                };
                GM_xmlhttpRequest({
                    method: "POST",
                    url: "/payments/reports/custom/request/refresh/ref=bb_tabela_cont_tabela",
                    headers: ZhiziPaymentsAll.amazonPaymentReportGenerateRequestHeader,
                    data: JSON.stringify(requestData),
                    onload: function (res) {
                        if (res.status == 200) {
                            ZhiziPaymentsAll.showLog("刷新" + ZhiziPaymentsAll.reportType + "报告状态的请求已经发送成功");
                            var begin = res.responseText.indexOf('<tr');
                            var end = res.responseText.lastIndexOf('</tr>');
                            var trBody = res.responseText.substring(begin, end + 5);
                            // console.log('刷新页面请求返回数据',res.responseText);
                            // console.log('刷新页面请求trBody',trBody);
                            // 重建当前页面，便于使用jquery访问报告数据
                            var tbody = document.createElement('tbody');
                            tbody.innerHTML = trBody;
                            var table = document.createElement('table');
                            table.appendChild(tbody);
                            if (document.getElementById('daterangereportstable')) {
                                document.getElementById('daterangereportstable').innerHTML = "";
                                document.getElementById('daterangereportstable').appendChild(table);
                            } else {
                                console.log('分页列表没加载出来，即将重载页面');
                                location.reload()
                            }
                            if (ZhiziPaymentsAll.autoDone) { // 自动正在执行状态下才有停止功能
                                ZhiziCommon.setMaskFoot('<button style="background-color: #00BCB4;border: 2px solid #00BCB4;margin:10pxcolor:#FFF;width:146px;" id="stopAutoHandler">停止自动上传</button>');
                                $('#stopAutoHandler').click(function() {
                                    clearInterval(ZhiziPaymentsAll.timer);
                                    ZhiziPaymentsAll.halfStop = true;
                                    ZhiziCommon.closeMask();
                                    ZhiziPaymentsAll.autoDone = false;
                                    ZhiziPaymentsAll.timer = setInterval(ZhiziPaymentsAll.autoCheckHandler, 3600 * 1000)
                                })
                            }
                            if (ZhiziPaymentsAll.halfStop) { // 中途停止状态直接就让他返回，不执行下面东西了
                                ZhiziPaymentsAll.halfStop = false;
                                return;
                            }
                            // console.log('刷新页面请求table',table);
                            var dateRange = $('#0-ddrDateRange').text().trim();
                            if (!ZhiziPaymentsAll.dateRangeMatch(dateRange, ZhiziPaymentsAll.dateRangeBegin, ZhiziPaymentsAll.dateRangeEnd)) {
                                ZhiziPaymentsAll.showLog('没有正确生成报告，请重试');
                                ZhiziCommon.showCloseBtn();
                                return;
                            }
                            var action = $('#0-ddrAction').text().trim();
                            console.log("action:" + action);
                            if (action.indexOf("Cancel") > -1) {
                                ZhiziPaymentsAll.showLog('报告生成请求已经上报,可能因为时区问题，结束日期尚未可用，可以考虑取消任务或者修改结束时间');
                                if (ZhiziPaymentsAll.autoDone) {
                                    ZhiziCommon.closeMask();
                                    ZhiziPaymentsAll.autoDone = false;
                                    location.reload()
                                }
                                ZhiziCommon.showCloseBtn();
                                return;
                            }
                            if (action.indexOf("Refresh") > -1) {
                                ZhiziPaymentsAll.refreshTimes++;
                                var interval = 30; //30s
                                if (ZhiziPaymentsAll.refreshTimes >= 10 * 60 / interval) {
                                    ZhiziPaymentsAll.showLog('亚马逊在10分钟内还没有生成' + ZhiziPaymentsAll.reportType + '报告，可以考虑分时间段采集或者重试');
                                    ZhiziCommon.showCloseBtn();
                                    ZhiziPaymentsAll.refreshTimes = 0
                                    if (ZhiziPaymentsAll.autoDone) { // 如果是正在处理自动生成状态出现这个问题，就让他重新走一次生成流程
                                        ZhiziCommon.closeMask();
                                        ZhiziPaymentsAll.autoDone = false;
                                    }
                                    return;
                                }
                                ZhiziPaymentsAll.showLog('亚马逊还没生成报告,插件将会在10分钟内每隔30s帮你看看亚马逊生成没, 你可以去忙别的事情了，回头来看看就行。已经重新看了:' + ZhiziPaymentsAll.refreshTimes + "次");
                                setTimeout(ZhiziPaymentsAll.refreshReport, interval * 1000);
                                return;
                            }

                            ZhiziPaymentsAll.showLog('报告可以下载');
                            var ddrDocumentName = $('#0-ddrDocumentName').text();
                            var hrefO = $('#0-ddrAction .a-button-text');
                            var href = hrefO.attr('href');
                            // debugger
                            if (ddrDocumentName.indexOf("Summary") > 0 && ZhiziPaymentsAll.reportType == "AllSummary") {
                                ZhiziPaymentsAll.downloadAndPost(href);
                                //break;==
                            } else if (ddrDocumentName.indexOf("Transaction") > 0 && ZhiziPaymentsAll.reportType == "AllPayments") {
                                ZhiziPaymentsAll.downloadAndPost(href);
                                //break;
                            } else {
                                ZhiziCommon.setMaskTitle('正在查询' + ZhiziPaymentsAll.reportType + '报告...');
                            }
                            return;
                        }
                        exception(res);
                    },
                    onabort: exception,
                    onerror: exception,
                    ontimeout: exception
                });
            },
            downloadAndPost: function (dl) {
                ZhiziCommon.setMaskTitle(ZhiziPaymentsAll.reportType === 'AllSummary' ? '类型：汇总，': '类型：交易，' + '下载报告...请耐心等待...如等待时间超过10分钟，请重新采集');
                ZhiziCommon.setMaskFoot('');
                var params = ZhiziPaymentsAll.parseUrl(dl);
                var fileName = params["fileName"];
                // debugger;
                var exception = function (res) {
                    console.log('下载报告错误=>', res)
                    ZhiziPaymentsAll.showLog("请求Amazon下载" + ZhiziPaymentsAll.reportType + "报告失败");
                    ZhiziCommon.showCloseBtn();
                    ZhiziPaymentsAll.refreshTimes = 0
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                    }
                };
                GM_xmlhttpRequest({
                    method: "GET",
                    url: dl,
                    responseType: 'blob',
                    timeout: 0,
                    onload: function (resp) {
                        console.log('下载报告响应=>', resp)
                        if (resp.status == 200) {
                            // debugger;
                            if (resp.response !== undefined){
                                ZhiziPaymentsAll.showLog('报告下载成功');
                                ZhiziCommon.setMaskFoot('报告下载成功');
                                var formData = new FormData();
                                formData.append("file", resp.response);
                                formData.append("fileName", fileName);
                                formData.append("site", ZhiziPaymentsAll.site);
                                formData.append("account", ZhiziPaymentsAll.account);
                                // formData.append("symbol", ZhiziPaymentsAll.symbol);
                                formData.append("begintime", ZhiziPaymentsAll.dateRangeBegin);
                                formData.append("endtime", ZhiziPaymentsAll.dateRangeEnd);
                                formData.append("data", resp.response);
                                formData.append("reportType", ZhiziPaymentsAll.reportType);

                                console.log("filename:" + fileName);
                                console.log("site:" + ZhiziPaymentsAll.site);
                                console.log("account:" + ZhiziPaymentsAll.account);
                                console.log("begintime:" + ZhiziPaymentsAll.dateRangeBegin);
                                console.log("endtime:" + ZhiziPaymentsAll.dateRangeEnd);
                                console.log("blob size:" + resp.response.size);
                                console.log("reportType", ZhiziPaymentsAll.reportType);
                                //TODO 上传文件到服务器
                                ZhiziPaymentsAll.sendData2Qulv(formData, 'https://erp.wandinghui.com/gateway/bcerp-sale/open/upload');
                            } else {
                                ZhiziPaymentsAll.showLog('浏览器返数据为空，在尝试重新下载数据');
                                ZhiziCommon.setMaskFoot('');
                                var xhr = new XMLHttpRequest();
                                xhr.open('get', dl);
                                xhr.responseType = 'blob';
                                xhr.send();
                                xhr.onload = function(){
                                    var formData = new FormData();
                                    formData.append("file", xhr.response);
                                    formData.append("fileName", fileName);
                                    formData.append("site", ZhiziPaymentsAll.site);
                                    formData.append("account", ZhiziPaymentsAll.account);
                                    // formData.append("symbol", ZhiziPaymentsAll.symbol);
                                    formData.append("begintime", ZhiziPaymentsAll.dateRangeBegin);
                                    formData.append("endtime", ZhiziPaymentsAll.dateRangeEnd);
                                    formData.append("data", xhr.response);
                                    formData.append("reportType", ZhiziPaymentsAll.reportType);

                                    console.log("filename:" + fileName);
                                    console.log("site:" + ZhiziPaymentsAll.site);
                                    console.log("account:" + ZhiziPaymentsAll.account);
                                    console.log("begintime:" + ZhiziPaymentsAll.dateRangeBegin);
                                    console.log("endtime:" + ZhiziPaymentsAll.dateRangeEnd);
                                    console.log("blob size:" + xhr.response.size);
                                    console.log("reportType", ZhiziPaymentsAll.reportType);
                                    ZhiziPaymentsAll.sendData2Qulv(formData, 'https://erp.wandinghui.com/gateway/bcerp-sale/open/upload');
                                }
                            }
                            return
                        }
                        exception(resp)
                    },
                    onprogress: function (res) {
                        ZhiziCommon.setMaskFoot('报告下载中...请耐心等待...' + (res.position / 1024).toFixed(2) + "KB");
                    },
                    onabort: exception,
                    onerror: exception,
                    ontimeout: exception
                });
            },
            consoleLogLong: function (title, data) {
                console.log("------------------" + title + "------------------");
                var maxLen = 1000;
                var len = data.length;
                var i = 0;
                while (len > maxLen) {
                    console.log(data.substr(i * maxLen, maxLen));
                    i = i + 1;
                    len = len - maxLen;
                }
                console.log(data.substr(i * maxLen));
            },
            showLog: function (message) {
                //ZhiziPaymentsAll.logMessage += ("<br>" + (++ZhiziPaymentsAll.logCnt) + " - ");
                //ZhiziPaymentsAll.logMessage += message;
                //$('#zhizi_mask_body').html(ZhiziPaymentsAll.logMessage);
                console.log(message);
                ZhiziCommon.setMaskBody("<br>" + (ZhiziPaymentsAll.reportType === 'AllSummary' ? '类型：汇总，': '类型：交易，') + message);
            },
            fmtDate: function (year, month, day) {
                if (day < 10) {
                    day = "0" + day;
                }
                if (month < 10) {
                    month = "0" + month;
                }
                return "" + year + "-" + month + "-" + day;
            },
            dateRangeMatch: function (dateRange, rangeBegin, rangeEnd) {
                var MonthMap = {
                    "Jan": 1,
                    "Feb": 2,
                    "Mar": 3,
                    "Apr": 4,
                    "May": 5,
                    "Jun": 6,
                    "Jul": 7,
                    "Aug": 8,
                    "Sep": 9,
                    "Oct": 10,
                    "Nov": 11,
                    "Dec": 12
                };

                //将时间范围的逗号跟点号去掉
                dateRange = dateRange.replace(/,/g,'').replace(/\./g,'');

                ZhiziPaymentsAll.showLog("dateRange: " + dateRange);
                ZhiziPaymentsAll.showLog("配置时间" + "begin: " + rangeBegin + ", end: " + rangeEnd);
                //MMM d, yyyy
                var datePattern1 = /(\w{3}) (\d{1,2}) (\d{4}) - (\w{3}) (\d{1,2}) (\d{4})/;
                // d MMM yyyy
                var datePattern2 = /(\d{1,2}) (\w{3}) (\d{4}) - (\d{1,2}) (\w{3}) (\d{4})/;

                /* // d MMM, yyyy
                 var datePattern3 = /(\d{1,2}) (\w{3}), (\d{4}) - (\d{1,2}) (\w{3}), (\d{4})/;
                 // d MMM. yyyy
                 var datePattern3a = /(\d{1,2}) (\w{3}). (\d{4}) - (\d{1,2}) (\w{3}). (\d{4})/;*/

                var getDate;
                var currentPattern;


                if (datePattern1.test(dateRange)) {
                    currentPattern = datePattern1;
                    getDate = function (regex, base) {
                        var month = MonthMap[regex[base + 1]];
                        var day = regex[base + 2];
                        var year = regex[base + 3];
                        return ZhiziPaymentsAll.fmtDate(year, month, day);
                    };
                } else if (datePattern2.test(dateRange)) {
                    currentPattern = datePattern2;
                    getDate = function (regex, base) {
                        var day = regex[base + 1];
                        var month = MonthMap[regex[base + 2]];
                        var year = regex[base + 3];
                        return ZhiziPaymentsAll.fmtDate(year, month, day);
                    };
                }
                /*else if (datePattern3.test(dateRange)) {
                    currentPattern = datePattern3;
                    getDate = function (regex, base) {
                        var day = regex[base + 1];
                        var month = MonthMap[regex[base + 2]];
                        var year = regex[base + 3];
                        return ZhiziPaymentsAll.fmtDate(year, month, day);
                    };
                } else if (datePattern3a.test(dateRange)) {
                    currentPattern = datePattern3a;
                    getDate = function (regex, base) {
                        var day = regex[base + 1];
                        var month = MonthMap[regex[base + 2]];
                        var year = regex[base + 3];
                        return ZhiziPaymentsAll.fmtDate(year, month, day);
                    };
                }*/
                else {
                    console.log('尚未识别的时间格式，先确认页面是否变成英文，如果没有变成英文，请反馈给技术人员');
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                        location.reload()
                    }
                    // alert('尚未识别的时间格式，先确认页面是否变成英文，如果没有变成英文，请反馈给技术人员');
                    return false;
                }
                var regex = currentPattern.exec(dateRange);
                var dtBegin = getDate(regex, 0);
                var dtEnd = getDate(regex, 3);
                return (dtBegin === rangeBegin && dtEnd === rangeEnd);
            },
            sendData2Qulv: function (data, sendUrl) {
                ZhiziCommon.setMaskTitle('上传报告到ERP系统（请不要关闭浏览器窗口，如有业务需求请重新打开一个浏览器窗口进行操作！！！）');
                ZhiziCommon.setMaskFoot('');
                ZhiziPaymentsAll.showLog("正在上传文件到ERP系统,请耐心等待....");
                var exception = function (resp) {
                    console.log(resp);
                    ZhiziPaymentsAll.showLog("发送文件到ERP系统失败");  
                    ZhiziPaymentsAll.refreshTimes = 0
                    if (ZhiziPaymentsAll.autoDone) {
                        ZhiziCommon.closeMask();
                        ZhiziPaymentsAll.autoDone = false;
                        location.reload()
                    }
                };
                GM_xmlhttpRequest({
                    method: "POST",
                    url: sendUrl,
                    data: data,
                    onload: function (resp) {
                        if (resp.status == 200) {
                            var response = JSON.parse(resp.response);
                            console.log(resp);
                            if (response.state !== 0) {
                                ZhiziCommon.setMaskFoot('出错，错误信息：' + response.msg);
                            } else {
                                ZhiziPaymentsAll.showLog("报告成功上传到ERP系统, 任务完成，请到ERP系统进行查看！");
                                if (ZhiziPaymentsAll.autoDone) {
                                    ZhiziPaymentsAll.uploadDoneHandler()
                                }
                            }
                            ZhiziPaymentsAll.refreshTimes = 0
                            ZhiziCommon.showCloseBtn();
                            return
                        }
                        exception(resp)
                    },
                    onabort: exception,
                    onerror: exception,
                    ontimeout: exception
                });
            },
            parseUrl: function (url) {
                var result = {};
                var query = url.split("?")[1];
                var queryArr = query.split("&");
                queryArr.forEach(function (item) {
                    var key = item.split("=")[0];
                    var value = item.split("=")[1];
                    result[key] = value;
                });
                return result;
            },
            getAccount: function () {
                var account = $('div.sc-footer-copy li').first().text().trim();
                if (account.length > 0) {
                    console.log('direct get account');
                    return account;
                } else {
                    console.log('ajax get account');
                    var url = "/hz/sc/account-information";
                    $.ajax({
                        url: url,
                        dataType: "html",
                        cache: false,
                        async: false,
                        error: function (XHR, textStatus, errorThrown) { },
                        success: function (html) {
                            return $(html).find("#headertext-SellerProfile")
                                .text().trim().replace("Welcome ", "");
                        }
                    });
                }
            },
            getCurrentSite: function () {
                if (window.location.hostname.indexOf("amazon.com.au") > 0) {
                    console.log('direct get au site');
                    return "www.amazon.com.au";
                }
                var sel = $('#sc-mkt-picker-switcher-select option[selected]');
                if (sel.length > 0) {
                    var site = sel.first().text().trim();
                    if (site.indexOf("www.amazon.") >= 0) {
                        console.log('get selected site');
                        return site;
                    }
                }
                console.log('get site');
                return $("#sc-mkt-switcher-form .sc-mkt-picker-switcher-txt").first().text().trim();
            },
            queryLastestDate: function () {
                ZhiziCommon.setMaskTitle(ZhiziPaymentsAll.reportType === 'AllSummary' ? '类型：汇总，': '类型：交易，' + '向ERP系统查询上一次采集时间范围');
                ZhiziCommon.setMaskFoot('');
                if (!ZhiziCommon.isEnglish()) {
                    ZhiziCommon.setMaskFoot('请把语言设置为英文(Please change language to English)');
                    ZhiziCommon.showCloseBtn();
                    return;
                }
                // 获取账号和站点
                ZhiziPaymentsAll.site = ZhiziCommon.getCurrentSite();
                ZhiziPaymentsAll.account = ZhiziCommon.getAccount().toLocaleLowerCase();
                ZhiziPaymentsAll.showLog("站点:" + ZhiziPaymentsAll.site);
                ZhiziPaymentsAll.showLog("账号:" + ZhiziPaymentsAll.account);
                if (ZhiziPaymentsAll.site.length == 0 || ZhiziPaymentsAll.account.length == 0) {
                    ZhiziCommon.setMaskFoot('获取账号和站点失败，请重试');
                    ZhiziCommon.showCloseBtn();
                    return;
                }
                ZhiziPaymentsAll.showDateRangeDialog();
            }
        };
        unsafeWindow.ZhiziPaymentsAll = ZhiziPaymentsAll;
    }
}