{
    matchStart: function () {
        // window.onload = function() {
        //     console.log('亚马逊页面加载完了..即将进行页面跳转')
        //     if (ZhiziCommon.getItem('isJump')){
        //         setTimeout(function() {
        //             location.href = 'https://sellercentral.amazon.com/payments/reports/custom/request?ref_=xx_report_ttab_dash'
        //         }, 5000)
        //     }
        // }
        $(document).ready(function() {
            console.log('亚马逊ready');
            ZhiziHomeTips.timer = setInterval(ZhiziHomeTips.jmupSite, 5000)
        })
        setTimeout(function() {
            ZhiziCommon.request({
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/getAvailableSiteInfo',
                data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}`
            }).then(res => {
                var siteInfo = {}
                if (res.data.siteInfo) {
                    siteInfo = JSON.parse(res.data.siteInfo)
                } else {
                    siteInfo.isJump = ""
                }
                console.log('超时函数',res.data.siteInfo, siteInfo);
                if (siteInfo.isJump && siteInfo.dateReport.autoOpen === 'on'){
                    console.log('亚马逊页面还没加载完，将执行页面重载')
                    location.reload()
                    console.log('执行完重载方法了！')
                } else {
                    console.log('清空了定时器');
                    clearInterval(ZhiziHomeTips.timer)
                }
            }).catch(error => {
                console.log('超时函数=>', error)
                setTimeout(function() {
                    location.reload()
                }, 300000)
            })
        }, 45000)
    },
    init: function () {
        var ZhiziHomeTips = {
            timer: null,
            // 站点跳转
			jmupSite() {
                // debugger
                console.log('正在执行跳转函数');
                let currentSite = $('#partner-switcher .dropdown-button span b').html() || $('#partner-switcher .dropdown-button span b').text() // 获取当前站点
                let load = document.getElementById('sc-mmp-dropdown-spinner')
                if (!ZhiziCommon.request) {
                    location.reload()
                    console.log('网络请求方法加载失败，页面即将重载！')
                    return;
                }
                ZhiziCommon.request({
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    url: 'https://erp.wandinghui.com/gateway/bcerp-sale/open/getAvailableSiteInfo',
                    data: `account=${ZhiziCommon.getAccount().toLocaleLowerCase()}`
                }).then(res => {
                    var siteInfo = {}
                    if (res.data.siteInfo) {
                        siteInfo = JSON.parse(res.data.siteInfo)
                    } else {
                        siteInfo.isJump = ""
                    }
                    if (siteInfo.isJump && currentSite && currentSite != undefined && !load && siteInfo.dateReport.autoOpen === 'on'){
                        console.log('跳转函数执行中', currentSite);
                        clearInterval(ZhiziHomeTips.timer)
                        setTimeout(function() {
                            console.log('亚马逊页面加载完了..即将进行页面跳转')
                            // location.href = `https://${ZhiziCommon.getDateRangeReportAddress()}/payments/reports/custom/request?ref_=xx_report_ttab_dash`
                            location.href = `https://${location.host}/payments/reports/custom/request?ref_=xx_report_ttab_dash`
                            // location.href = 'https://sellercentral.amazon.com/payments/reports/custom/request?ref_=xx_report_ttab_dash'
                        }, 3000)
                    } else {
                        ZhiziCommon.setItem('sysLog', Object.assign(ZhiziCommon.getItem('sysLog') || {}, {
                            "time": ZhiziCommon.getDateString(new Date(), null, true),
                            'event': '当前站点' + currentSite + ', 加载动画：' + load ? '存在': '不存在' + '跳转失败' + ',自动开启状态：' + siteInfo.dateReport.autoOpen === 'on' ? '开启' : '关闭'
                        }))
                    }
                }).catch(error => {
                    console.log('跳转函数=>', error)
                    setTimeout(function() {
                        location.reload()
                    }, 300000)
                })
            }
        };
        unsafeWindow.ZhiziHomeTips = ZhiziHomeTips;
    }
}
