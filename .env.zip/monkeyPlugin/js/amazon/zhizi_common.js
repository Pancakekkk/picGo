/**
 *
 * @name zhiziCommon js代码
 *
 */
{
	init: function () {
		var version = "2250";

		console.log("初始化common");
		/**
		 * 通过key，获取value的值，如果为空，则返回 null
		 * 此方法的使用，务必配合 localStorageSet()方法使用
		 * @param key 获取value的key值
		 * @returns {null|*}
		 */
		function localStorageGet(key) {
			let data = JSON.parse(localStorage.getItem(key));
			if (data !== null) {
				if (data.expirse != null && data.expirse < new Date().getTime()) {
					localStorage.removeItem(key);
				} else {
					return data.value;
				}
			}
			return null;
		}
		var ZhiziPlugins = {
			homeTips: {
				name: '首页',
				// Math.round(Math.random() * 1000)
				// url: ZhiziWebsite.jsUrl + '/js/amazon/home.js?v=' + Math.round(Math.random() * 1000),
				url: ZhiziWebsite.jsUrl + '/js/amazon/home.js?v=' + 10095,
				active: true,
				matchUrl: ['/home']
			},
			standardPaymentsDownload: {
				name: '日期范围报告下载',
				// url: ZhiziWebsite.jsUrl + '/js/amazon/payments.js?v=' + Math.round(Math.random() * 1000),
				url: ZhiziWebsite.jsUrl + '/js/amazon/payments.js?v=' + 10095,
				active: true,
				matchUrl: ['/payments/reports/custom/request']
			}
		};

		var ZhiziCommon = {
			masking: false,
			account: '',
			jsSortArr: [],
			jsArr: [],//该界面所有加载的js
			jsNum: 0,//该界面所有需要加载的js数量
            siteMapping: {
                'Canada': 'www.amazon.ca',
                'Germany': 'www.amazon.de',
                'Spain': 'www.amazon.es',
                'France': 'www.amazon.fr',
                'Italy': 'www.amazon.it',
                'Japan': 'www.amazon.co.jp',
                'UnitedKingdom': 'www.amazon.co.uk',
                'UnitedStates': 'www.amazon.com',
                'Mexico': 'www.amazon.com.mx',
                'UnitedArabEmirates': 'www.amazon.ae',
                'Brazil': 'www.amazon.com.br',
                'Singapore': 'www.amazon.sg',
                'Sweden': 'www.amazon.se',
                'Turkey': 'www.amazon.com.tr',
                'Australia': 'www.amazon.com.au',
                'Netherlands': 'www.amazon.nl',
                'SaudiArabia': 'www.amazon.sa',
                'India': 'www.amazon.in',
                'Poland': 'www.amazon.pl'
            },
			url: function (params) {
				var apiUrl = ZhiziWebsite.apiUrl + params;
				console.log("url: " + apiUrl);
				return apiUrl;
			},
			/**
			 * 初始化toolbar的按钮
			 */
			toolbar: function () {
				var toolbar = "<div id='zhizi_toolbar'>"
					+ "<div id='zhizi_show_toolbar' class='zhizi_button_style' >点击隐藏</div>"
					// + "<div id='zhizi_toolbar_move' class='zhizi_button_style' >按住可拖动</div>"
					+ "<ul style='background:  rgba(10,33,225,0.8);padding:0;margin:0;'></ul>"
					+ "</div>";
				//从缓存中取上次toolbar距离左侧的距离，默认为0
				var zhizi_toolbar_left = localStorage.getItem("zhizi_toolbar_left");
				if (zhizi_toolbar_left == null) {
					zhizi_toolbar_left = 0;
				} else {
					//防止如果移动超过限制，按钮看不见，回到0的位置
					var maxMoveWidth = document.body.clientWidth / 2;
					if (zhizi_toolbar_left < 0 || zhizi_toolbar_left > maxMoveWidth) {
						zhizi_toolbar_left = 0;
					}
				}
				//将样式统一
				GM_addStyle("#zhizi_toolbar {position: fixed;top: 5px;left: " + zhizi_toolbar_left + "px;min-width:100px;color: #FFF !important;z-index: 999;text-align: center;border-color: rgba(8, 158, 152, 0.5);border:0;font-size: 14px;line-height: 30px;cursor: pointer;}" +
					".zhizi_button_style {background:rgba(65,105,225, 0.8);border-bottom: 2px solid;}");
				$('body').append(toolbar);
				//按钮的展示和隐藏
				ZhiziCommon.showOrHideButton();
				//移动toolbar的功能菜单
				ZhiziCommon.moveToolbarButton();
				//点击切换test环境
				// ZhiziCommon.switchFormalOrTestEnv();
			},
			/**
			 * 显示/隐藏 功能菜单
			 */
			showOrHideButton: function () {
				//根据浏览器缓存，判断的是否隐藏按钮
				var $zhizi_toolbar_ul = $("#zhizi_toolbar ul");
				var $zhizi_show_toolbar = $("#zhizi_show_toolbar");
				var $zhizi_toolbar_move = $("#zhizi_toolbar_move");
				var hideTitle = "点击隐藏";
				var showTitle = "点击显示";
				if (localStorage.getItem("zhizi_localStorage_toolbar_key") == "hide") {
					$zhizi_show_toolbar.text(showTitle);
					$zhizi_toolbar_ul.hide();
					$zhizi_toolbar_move.hide();
				} else {
					$zhizi_show_toolbar.text(hideTitle);
					$zhizi_toolbar_ul.show();

				}
				//显示隐藏按钮
				$("#zhizi_show_toolbar").click(function () {
					if ($zhizi_toolbar_ul.css('display') == 'none') {
						localStorage.setItem("zhizi_localStorage_toolbar_key", "show");
						$zhizi_show_toolbar.text(hideTitle);
						$zhizi_toolbar_ul.show();
						$zhizi_toolbar_move.show();
					} else {
						localStorage.setItem("zhizi_localStorage_toolbar_key", "hide");
						$zhizi_show_toolbar.text(showTitle);
						$zhizi_toolbar_ul.hide();
						$zhizi_toolbar_move.hide();
					}
				});
			},
			/**
			 * 点击toolbar区域，可以根据鼠标的移动而移动
			 */
			moveToolbarButton: function () {
				$('#zhizi_show_toolbar').mousedown(function () {
					console.log("按下鼠标左键，触发mousemove的功能");
					//按下鼠标左键，触发mousemove的功能
					$(document).mousemove(function (e) {
						var xPosition = e.pageX;
						//console.log("拖动mousemove:x=" + xPosition + "y=" + e.pageY);
						var maxMoveWidth = document.body.clientWidth / 2;
						if (xPosition < 0 || xPosition > maxMoveWidth) {
							$("#zhizi_show_toolbar").html("有堵墙，过不去了");
							return;
						}
						$("#zhizi_toolbar").css("left", xPosition + "px");
						localStorage.setItem("zhizi_toolbar_left", xPosition);
					});
					//松开鼠标左键,unbind mousemove的功能
					$(document).mouseup(function () {
						console.log("松开鼠标左键,解除移动功能");
						$("#zhizi_show_toolbar").html("按住可拖动");
						$(document).unbind('mousemove');
					})
				});
			},
			/**
			 * 添加功能菜单
			 * @param id 元素id="" 的value值，可以方便dom操作
			 * @param name 展示的按钮名称
			 * @param bindFn 点击此按钮后，触发的函数
			 */
			addPluginToolbar: function (id, name, bindFn) {
				$('#zhizi_toolbar ul').append(
					'<li id="' + id + '" style="list-style-type:none;padding:0 10px;color:#fff !important; border-bottom: 2px solid;">'
					+ name + '</li>');
				if (typeof (bindFn) !== "undefined") {
					$('#' + id).click(bindFn);
				}
			},
			GMGet: function (url, successCallback, errorCallback) {
				GM_xmlhttpRequest({
					method: "get",
					url: url,
					onload: function (res) {
						if (res.status == 200) {
							successCallback(res);
						} else {
							errorCallback(res);
						}
					},
					onerror: function (res) {
						errorCallback(res);
					}
				});
			},
			GMPost: function (url, data, successCallback, errorCallback) {
				console.log("postData" + JSON.stringify(data));
				GM_xmlhttpRequest({
					method: "post",
					url: url,
					data: JSON.stringify(data),
					headers: {
						"Content-Type": "application/json"
					},
					onload: function (res) {
						if (res.status == 200) {
							successCallback(res);
						} else {
							errorCallback(res);
						}
					},
					onerror: function (res) {
						errorCallback(res);
					}
				});
			},
			/**
			 * 打开遮罩层
			 */
			openMask: function () {
				if (!ZhiziCommon.masking) {
					var html = '<div id="zhizi_mask" style="color:#fff;font-size:15px;width:100%;height:100%;position:fixed;top:0;left:0;z-index:99999;background: rgba(0,0,0,.8)">'
						+ '<div class="zhizi-function">'
						+ '<div style="margin-top:7%;text-align:center;font-size:20px">'
						+ '<div id="zhizi_mask_title"></div><br>'
						+ '<div id="zhizi_mask_body" style="margin-top:10px"></div>'
						+ '<div id="zhizi_mask_foot" style="margin-top:10px"></div>'
						+ '<div id="zhizi_mask_close" style="margin-top:10px;display:none">'
						+ '<button style="background-color: #00a9a2;border: 2px solid #00BCB4;">关闭</button>'
						+ '</div>' + '</div>' + '</div>' + '</div>';
					$('body').append(html);
					$('#zhizi_mask_close>button').click(function () {
						ZhiziCommon.closeMask();
					});
					ZhiziCommon.masking = true;
				}
			},
			/**
			 * 关闭遮罩层
			 */
			closeMask: function () {
				$('#zhizi_mask').remove();
				ZhiziCommon.masking = false;
			},
			setHtml: function (el, html, append) {
				if (append) {
					$(el).append(html);
				} else {
					$(el).html(html);
				}
			},
			/**
			 * 在遮罩层 的 title（头部） 区域，加入html
			 * @param html 加入的html内容
			 * @param append 是否追加
			 */
			setMaskTitle: function (html, append) {
				ZhiziCommon.setHtml('#zhizi_mask_title', html, append);
			},
			/**
			 * 在遮罩层 的 body（中间） 区域，加入html
			 * @param html 加入的html内容
			 * @param append 是否追加
			 */
			setMaskBody: function (html, append) {
				ZhiziCommon.setHtml('#zhizi_mask_body', html, append);
			},
			/**
			 * 在遮罩层 的 foot(底部) 区域，加入html
			 * @param html 加入的html内容
			 * @param append 是否追加
			 */
			setMaskFoot: function (html, append) {
				ZhiziCommon.setHtml('#zhizi_mask_foot', html, append);
			},
			/**
			 * 隐藏关闭按钮
			 */
			hideCloseBtn: function () {
				$('#zhizi_mask_close').hide();
			},
			/**
			 * 展示关闭按钮
			 */
			showCloseBtn: function () {
				$('#zhizi_mask_close').show();
				$('#zhizi_mask_close>button').click(function () {
					ZhiziCommon.closeMask();
				});
			},
			getUtilScript: function (url, name) {
				var startTime = new Date(); //开始时间
				// console.log(url+"开始加载....");
				var flag = true;
				ZhiziCommon.GMGet(ZhiziWebsite.jsUrl + url, function (res) {
					var obj = eval('(' + res.responseText + ')');
					obj.init();//初始化函数
					// obj.matchStart();
					var endTime = new Date(); //结束时间
					var result = endTime.getTime() - startTime.getTime();//时间差的毫秒数
					console.log(url + "加载完成，共花费了----" + result + "毫秒");
					flag = false;
				}, function (res) {
					setTimeout(function () {
						//如果1秒之后。flag还是为true，则重新加载
						if (flag) {
							ZhiziCommon.getUtilScript(url);
						}
					}, 1000);

				});
			},
			getScript: function (url, name) {
				var startTime = new Date(); //开始时间
				// console.log(url+"开始加载....");
				var flag = true;
				ZhiziCommon.GMGet(url, function (res) {
					var obj = eval('(' + res.responseText + ')');
					obj.name = name; //加入名称，对名称进行排序
					ZhiziCommon.jsArr.push(obj);
					// obj.init();
					// obj.matchStart();
					var endTime = new Date(); //结束时间
					var result = endTime.getTime() - startTime.getTime();//时间差的毫秒数
					console.log(url + " 加载完成，耗时" + result + "ms");
					flag = false;
				}, function (res) {
					setTimeout(function () {
						//如果15秒之后。flag还是为true，则重新加载
						if (flag) {
							ZhiziCommon.getScript(url);
						}
					}, 15000);
				});
			},
			initPlugins: function () {
				var locationUrl = location.href;
                //debugger
				$.each(ZhiziPlugins, function (i, item) {
					for (var j = 0; j < item.matchUrl.length; j++) {
						var u = item.matchUrl[j];
						if (u == '*' || locationUrl.indexOf(u) >= 0) {
							ZhiziCommon.jsSortArr.push(item.name);//排序的Name
							ZhiziCommon.getScript(item.url, item.name);
							ZhiziCommon.jsNum++;
						}
					}
				});
				//等待js全部加载完成后，进行js的整体加载
				var sortButton = setInterval(function () {
					if (ZhiziCommon.jsNum == ZhiziCommon.jsArr.length) {
						window.clearInterval(sortButton);
						console.log("预计加载" + ZhiziCommon.jsSortArr.length + "个按钮,现加载" + ZhiziCommon.jsArr.length);
						for (var i = 0; i < ZhiziCommon.jsSortArr.length; i++) {
							var sortName = ZhiziCommon.jsSortArr[i];
							for (var j = 0; j < ZhiziCommon.jsArr.length; j++) {
								var obj = ZhiziCommon.jsArr[j];
								if (sortName === obj.name) {
									//此处执行的是每个子js文件push进来后的里面的函数，所以，每个子文件必须包含这两个函数
                                    obj.init();
                                    obj.matchStart();
									break;
								}
							}
						}
					}
				}, 500);
			},
			/**
			 * sellerCenter获取account的方法
			 */
			getAccount: function () {
				if (ZhiziCommon.account != '') {
					console.log("--使用了帐号缓存--", ZhiziCommon.account);
					return ZhiziCommon.account;
				}
				return ZhiziCommon.getAccountTypeOne();
			},
			getAccountTypeOne: function () {
				var account = $("#sc-mkt-switcher-form .sc-mkt-picker-switcher-txt").text().trim();
				if (account.length > 0 && account.indexOf("www.") == -1) {
					ZhiziCommon.account = account;
					return account;
				} else {
					console.log('before ajax get account：' + account);
					console.log(account.indexOf("www.") == -1)
                    var url = '';
					/*var host = window.location.host;
					if (host.indexOf('advertising')>=0){
						url = 'https://'+host.replace('advertising','sellercentral');
					}*/
					url += "/hz/sc/account-information";
					console.log(url);
					$.ajax({
						url: url,
						dataType: "html",
						cache: false,
						async: false,
						error: function (XHR, textStatus, errorThrown) {
						},
						success: function (html) {
							//debugger;
							account = $(html).find('#headertext-SellerProfile').text()
								.replace("Welcome", "").replace("欢迎", "").replace("(Edit)", "").replace("(编辑)", "").trim();
							console.log('success ajax get account:---' + account);
						}
					});
					if (!account) {
						account = $('.partner-label').text()
					}
					console.log('last ajax get account:---' + account);
					ZhiziCommon.account = account;
					return account;
				}
			},

			/**
			 * amazon获取站点的方法
			 */
			getCurrentSite: function () {
				if (window.location.host.indexOf("advertising") != -1) {
					console.log("advertising网址无法使用此方法获取站点");
					return;
				}
                if($("#partner-switcher").length>0)
                {
                    var btn = $('#partner-switcher .dropdown-button').text() || $('#partner-switcher .partner-dropdown-button').text();
                    if (btn.length > 0){
                        var sitArr = btn.split("|");
                        if (sitArr.length > 1) {
                            // debugger
                            var reg=new RegExp(' ',"g");
                            var siteStr = sitArr[1].trim().replace(reg,'');
                            var site = ZhiziCommon.siteMapping[siteStr];
                            if (!site){
                                if(ZhiziCommon.isEnglish()){
                                    ZhiziCommon.setMaskFoot("此站点还未支持采集，请联系主管处理！" );
                                }else {
                                    ZhiziCommon.setMaskFoot("当前非英文环境，请切换成英文后再试！" );
                                }
                            }
                            console.log('get btn site：' + site);
                            return site;
                        }else {
                            ZhiziCommon.setMaskFoot("抱歉，机器人 在界面暂时未发现 domain数据，请点击关闭按钮 或 刷新后重试，当前domain：" + site )
                        }
                    }
                }
                else
                {
                    var sel = $('#sc-mkt-picker-switcher-select option[selected]');
                    if (sel.length > 0) {
                        var site = sel.first().text();
                        var sitArr = site.split("-");
                        if (sitArr.length > 1) {
                            site = sitArr[0];
                        }
                        if (site.indexOf("www.amazon.") >= 0) {
                            console.log('get selected site：' + site);
                            return site.trim();
                        }
                    }
                    console.log('get site：' + sel);
                    var site = $("#sc-mkt-switcher-form  .sc-mkt-picker-switcher-txt")
                        .first().text().trim();
                    if (site.indexOf("www.amazon.") == -1) {
                        ZhiziCommon.setMaskFoot("抱歉，机器人 在界面暂时未发现 domain数据，请点击关闭按钮 或 刷新后 重试，当前domain：" + site);
                    }
                    return site;
                }

			},
			/**
			 * 获取sellerId
			 */
			getAdsSellerId: function () {
				var adviceAccountUrl = "/account";
				var sellerId = "";
				$.ajax({
					url: adviceAccountUrl,
					dataType: "html",
					cache: false,
					async: false,
					error: function (XHR, textStatus, errorThrown) {
					},
					success: function (html) {
						sellerId = $(html).find(".account").eq(0).attr("data-customer-id");

					}
				});
				console.log('success ajax get sellerID:---' + sellerId);
				return sellerId;
			},
            /**
             * 获取adsAccount
             */
            getAdsAccount: function (num) {
            	var ZhizicommonAccount = localStorage.getItem('ZhiziCommonAccount');
            	if (ZhizicommonAccount!==null){
            		console.log('localStorage get account:'+ZhizicommonAccount);
                    ZhiziCommon.account = ZhizicommonAccount;
				}else{

                    var req = new XMLHttpRequest();
                    if (req != null) {
                    	req.onreadystatechange = function() {
							if (req.readyState == 4) {
                    			if ((req.status >= 200 && req.status < 300) || req.status == 304) {
                    				alet(req.responseText);
                                }    //获取成功就弹出取得的内容
							} else {
								alert("Request was unsuccessful: " + req.status);
							}
                    	}
                    };
                    req.open("GET",url, true);    //url是获取的地址
					req.send(null);



                    var url = '';
                    var host = window.location.host;
                    if (host.indexOf('advertising')>=0){
                        url = 'https://'+host.replace('advertising','sellercentral');
                    }
                    url += "/hz/sc/account-information";
                    console.log(url+'---获取account数据---第'+num+'次');
                    GM_xmlhttpRequest({
                        method: "get",
                        url: url,
                        responseType: 'blob',
                        synchronous: true,
                        timeout: 10000,
                        onload: function (resp) {
                            var html = resp.responseText;
                            console.log(resp);
                            // debugger
                            var account = ZhiziCommon.getStr(html,'Welcome','\<a href');
                            // debugger;
                            console.log(account);
                            if (account===null){
                                account = ZhiziCommon.getStr(html,'欢迎','\<a href');
                                if (account===null){
                                    ZhiziCommon.openMask();
                                    ZhiziCommon.setMaskBody('<img src="'+ ZhiziWebsite.jsUrl +'/img/sp_tip.png">');
                                    ZhiziCommon.setMaskFoot('请确保当前站点的店铺后台已登录并切换英文环境，如果还是获取不到账号，请点击<a href="'+url+'" target="_blank" style="color: red">点击此处</a>登录页面后切换英文环境再重新采集');
                                    ZhiziCommon.showCloseBtn();
                                    return;
                                }
                            }else {
                                ZhiziCommon.account = account.trim();
                                localStorage.setItem('ZhiziCommonAccount',ZhiziCommon.account);
                            }
                        },
                        onerror: function (resp) {
                            var times = num+1;
                            console.log('获取account失败')
                            if (times<=5){
                                setTimeout(function(){
                                    ZhiziCommon.getAdsAccount(times);
                                },3000)
                            }else {
                                console.log('获取account数据次数超限，请刷新后重试');
                            }
                        },

                        ontimeout: function (resp) {
                            var times = num+1;
                            console.log('获取account超时')
                            if (times<=5){
                                setTimeout(function(){
                                    ZhiziCommon.getAdsAccount(times);
                                },3000)
                            }else {
                                console.log('获取account数据次数超限，请刷新后重试');
                            }
                        }
                    });
				}

            },
            /**
             * 已知前后文 取中间文本
             * @param str 全文
             * @param start 前文
             * @param end 后文
             * @returns 中间文本 || null
             */
            getStr:function(str, start, end) {
                let res = str.match(new RegExp(`${start}(.*?)${end}`))
                return res ? res[1] : null
            },
			/**
			 * advertising开头的获取站点
			 * ads的映射： 站点名称  转 amazon的站点
			 * 例如：France -->www.amazon.fr
			 */
			getAdsCurrentSite: function () {
				var adsCurrentSite = $('#AACChromeHeaderAccountDropdown div[class^="CurrentMarketplaceInfo"]').text();
				var mapObj = new Map();
				mapObj.set("India", "www.amazon.in");
				mapObj.set("United Arab Emirates", "www.amazon.ae");
				mapObj.set("Australia", "www.amazon.com.au");
				mapObj.set("United States", "www.amazon.com");
				mapObj.set("Canada", "www.amazon.ca");
				mapObj.set("Mexico", "www.amazon.com.mx");
				mapObj.set("United Kingdom", "www.amazon.co.uk");
                mapObj.set("Netherlands", "www.amazon.nl");

				mapObj.set("Germany", "www.amazon.de");
				mapObj.set("Deutschland", "www.amazon.de");

				mapObj.set("France", "www.amazon.fr");
				mapObj.set("Italy", "www.amazon.it");
				mapObj.set("Italia", "www.amazon.it");

				mapObj.set("Spain", "www.amazon.es");
				mapObj.set("España", "www.amazon.es");

				mapObj.set("日本", "www.amazon.co.jp");
				mapObj.set("Japan", "www.amazon.co.jp");

				mapObj.set("Saudi Arabia", "www.amazon.sa");
                mapObj.set("Singapore", "www.amazon.sg");
                mapObj.set("Brazil", "www.amazon.com.br");

				console.log("获取到ADS原始站点为：" + adsCurrentSite);
				var amazonSite = mapObj.get(adsCurrentSite);
				console.log("转换后的ADS站点为：：" + amazonSite);
				if (amazonSite == undefined) {
					alert("amazonSite站点转换失败，失败原因" + adsCurrentSite + "未找到mapping，请发群里联系开发人员解决")
				}
				return amazonSite;
			},
			// 日期范围报告地址站点映射
			getDateRangeReportAddress() {
				var adsCurrentSite = $('.merchant-level li a[class="currentSelection').text();
				var mapObj = new Map();
				mapObj.set("India", "sellercentral.amazon.in");
				mapObj.set("United Arab Emirates", "sellercentral.amazon.ae");
				mapObj.set("Australia", "sellercentral.amazon.com.au");
				mapObj.set("United States", "sellercentral.amazon.com");
				mapObj.set("Canada", "sellercentral.amazon.com");
				mapObj.set("Mexico", "sellercentral.amazon.com");
				mapObj.set("United Kingdom", "sellercentral.amazon.co.uk");
                mapObj.set("Netherlands", "sellercentral.amazon.nl");

				mapObj.set("Germany", "sellercentral.amazon.de");
				mapObj.set("Deutschland", "sellercentral.amazon.de");

				mapObj.set("France", "sellercentral.amazon.fr");
				mapObj.set("Italy", "sellercentral.amazon.it");
				mapObj.set("Italia", "sellercentral.amazon.it");

				mapObj.set("Spain", "sellercentral.amazon.es");
				mapObj.set("España", "sellercentral.amazon.es");

				mapObj.set("日本", "sellercentral-japan.amazon.com");
				mapObj.set("Japan", "sellercentral-japan.amazon.com");

				mapObj.set("Saudi Arabia", "sellercentral.amazon.sa");
                mapObj.set("Singapore", "sellercentral.amazon.sg");
                mapObj.set("Brazil", "sellercentral.amazon.com.br");

				console.log("获取到当前站点为：" + adsCurrentSite);
				var amazonSite = mapObj.get(adsCurrentSite);
				console.log("转换后的日期范围报告地址站点地址为：：" + amazonSite);
				if (amazonSite == undefined) {
					alert("amazonSite站点转换失败，失败原因" + adsCurrentSite + "未找到mapping，请发群里联系开发人员解决")
				}
				return amazonSite;
			},
			/**
			 * amazon后台的英语判断
			 * @returns {boolean}
			 */
			isEnglish: function () {
				if (window.location.hostname.indexOf("amazon.in") > 0) {
					return true;
				}
				var lang = $('#sc-lang-switcher-header-select  option[selected]')
					.first().text().trim();
				var newLang = $('.locale-icon-wrapper').text().trim();
				return lang === 'English'||newLang==='EN';
			},
			/**
			 * 以ads网址开头的英文环境判断
			 * @returns {boolean}
			 */
			isAdsEnglish: function () {
				var languageStr = $("#languageSwitcher input:checked+div").text();
				// var languageStr = '';
				// for (var i = 0; i < $_language.length; i++) {
				// 	if ($_language[i].checked) {
				// 		languageStr = $_language.eq(i).next().text();
				// 		break;
				// 	}
				// }
				//判断是否是英文
				return languageStr == "English";
			},
			getMaskDateObj: function (maskId, date, tag) {
				if ($('#' + maskId).length === 0) {
					ZhiziCommon.setMaskBody('<div id="' + maskId + '" style="margin-top:10px;overflow-y:auto;"></div>', true);
				}
				var id = maskId + '_' + date;
				var obj = $('#' + id);
				if (obj.length === 0) {
					$('#' + maskId).prepend('<' + tag + ' id="' + id + '" retrytimes=0 style="padding:5px 10px;"></' + tag + '>');
					obj = $('#' + id);
				}
				return obj;
			},
			setMaskDateStatusItem: function (date, status) {
				var obj = ZhiziCommon.getMaskDateObj('zhizi_mask_item', date, 'span');
				obj.html(date + ": " + status);
			},
			setMaskItem: function (maskId, idIndex, tag, mgs) {
				var obj = ZhiziCommon.getMaskDateObj(maskId, idIndex, tag);
				obj.html(mgs);
			},
			/**
			 * 此方法慎用，会导致电脑的CUP压力比较大，要找个更优的方案才行
			 * @param callbackFun
			 * @param ms
			 */
			sleep: function (ms) {
				var start = new Date().getTime();
				console.log('休眠前：' + start);
				while (true) {
					if (new Date().getTime() - start > ms) {
						break;
					}
				}
				console.log('休眠后：' + new Date().getTime());

			},
			/**
			 * 获取指定的URL参数值
			 * URL:http://www.quwan.com/index?name=tyler
			 * 参数：paramName URL参数
			 * 调用方法:getParam("name")
			 * 返回值:tyler
			 */
			getParam: function (url, name) {
				var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
				var arr = url.split("?");
				if (arr.length >= 2) {
					var searchUrl = arr[1];
					var r = searchUrl.match(reg);
					if (r != null) return unescape(r[2]);
				}
				return null;
			},
			/**
			 * 网上找的程序，有时候不是非常非常的好使，看到这么多case，就头大
			 * @param now  date时间类:new Date()
			 * @param mask  格式化：“yyyy-MM-dd”
			 * @returns {void | string}
			 */
			formatDate: function (now, mask) { //时间格式化工具
				var d = now;
				var zeroize = function (value, length) {
					if (!length) length = 2;
					value = String(value);
					for (var i = 0, zeros = ''; i < (length - value.length); i++) {
						zeros += '0';
					}
					return zeros + value;
				};

				return mask.replace(/"[^"]*"|'[^']*'|\b(?:d{1,4}|m{1,4}|yy(?:yy)?|([hHMstT])\1?|[lLZ])\b/g, function ($0) {
					switch ($0) {
						case 'd':
							return d.getDate();
						case 'dd':
							return zeroize(d.getDate());
						case 'ddd':
							return ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'][d.getDay()];
						case 'dddd':
							return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getDay()];
						case 'M':
							return d.getMonth() + 1;
						case 'MM':
							return zeroize(d.getMonth() + 1);
						case 'MMM':
							return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
						case 'MMMM':
							return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][d.getMonth()];
						case 'yy':
							return String(d.getFullYear()).substr(2);
						case 'yyyy':
							return d.getFullYear();
						case 'h':
							return d.getHours() % 12 || 12;
						case 'hh':
							return zeroize(d.getHours() % 12 || 12);
						case 'H':
							return d.getHours();
						case 'HH':
							return zeroize(d.getHours());
						case 'm':
							return d.getMinutes();
						case 'mm':
							return zeroize(d.getMinutes());
						case 's':
							return d.getSeconds();
						case 'ss':
							return zeroize(d.getSeconds());
						case 'l':
							return zeroize(d.getMilliseconds(), 3);
						case 'L':
							var m = d.getMilliseconds();
							if (m > 99) m = Math.round(m / 10);
							return zeroize(m);
						case 'tt':
							return d.getHours() < 12 ? 'am' : 'pm';
						case 'TT':
							return d.getHours() < 12 ? 'AM' : 'PM';
						case 'Z':
							return d.toUTCString().match(/[A-Z]+$/);
						// Return quoted strings with the surrounding quotes removed
						default:
							return $0.substr(1, $0.length - 2);
					}
				});
			},
			/**
			 *  往浏览区的localStorage区域设置缓存
			 * @param key  key值，get的时候，通过key获取value
			 * @param value  所存的值
			 * @param ttl_ms  经过过少毫秒后，将会过期，此参数务必配合 localStorageGet(key)方法 使用
			 */
			localStorageSet: function (key, value, ttl_ms) {
				var expirationTime = new Date().getTime() + ttl_ms;
				var data = {value: value, expirse: expirationTime};
				localStorage.setItem(key, JSON.stringify(data));
			},
			/**
			 * 通过key，获取value的值，如果为空，则返回 null
			 * 此方法的使用，务必配合 localStorageSet()方法使用
			 * @param key 获取value的key值
			 * @returns {null|*}
			 */
			localStorageGet: localStorageGet,

			// 本地存储封装
			setItem: function (key,val){
				let obj = ZhiziCommon.getStroage();
				obj[key] = val;
				window.localStorage.setItem('config_erp', JSON.stringify(obj));
			},
			//获取本地已存储的数据
			getStroage: function (){
				return JSON.parse(window.localStorage.getItem('config_erp')) || {};
			},
			getItem: function (key){
				return ZhiziCommon.getStroage()[key] != null ? ZhiziCommon.getStroage()[key] : null;
			},
			clearItem: function (key){
				let obj = ZhiziCommon.getStroage();
				delete obj[key];
				window.localStorage.setItem('config_erp',JSON.stringify(obj));
			},
			clearAll(){
				window.localStorage.clear();
			},
			// 深拷贝
			deepClone(data) {
				var type = ZhiziCommon.getType(data)
				var obj
				if (type === 'array') {
					obj = []
				} else if (type === 'object') {
					obj = {}
				} else {
				  	// 不再具有下一层次
				  	return data
				}
				if (type === 'array') {
					for (var i = 0, len = data.length; i < len; i++) {
						obj.push(ZhiziCommon.deepClone(data[i]))
					}
				} else if (type === 'object') {
					for (var key in data) {
						obj[key] = ZhiziCommon.deepClone(data[key])
					}
				}
				return obj
			},
			getType(obj) {
				// tostring会返回对应不同的标签的构造函数
				var toString = Object.prototype.toString
				var map = {
					'[object Boolean]': 'boolean',
					'[object Number]': 'number',
					'[object String]': 'string',
					'[object Function]': 'function',
					'[object Array]': 'array',
					'[object Date]': 'date',
					'[object RegExp]': 'regExp',
					'[object Undefined]': 'undefined',
					'[object Null]': 'null',
					'[object Object]': 'object'
				}
				if (obj instanceof Element) {
				  	return 'element'
				}
				return map[toString.call(obj)]
			},
			// 网络请求封装
			request(obj) {
				return new Promise((resolve, reject) => {
					var exception = function (error) {
						console.log(error);
						reject(error)
					}
					// { "Content-Type": "application/x-www-form-urlencoded" }
					GM_xmlhttpRequest({
						method: obj.method,
						headers: obj.headers, 
						url: obj.url,
						data: obj.data,
						onload: function (resp) {
							resolve(JSON.parse(resp.response))
						},
						onabort: exception,
						onerror: exception,
						ontimeout: exception
					});
				})
			},
			// 获取时间格式化，年-月-日
			getDateString(date, format, isTime = false) {
				const d = date || new Date()
				const f = format || 'yyyy-mm-dd'
				const _year = d.getFullYear()
				const _month = d.getMonth() + 1 < 10 ? '0' + (d.getMonth() + 1) : d.getMonth() + 1
				const _day = d.getDate() < 10 ? '0' + d.getDate() : d.getDate()
				const _hours = d.getHours()
				const _minutes = d.getMinutes()
				const _seconds = d.getSeconds()
				if (f === 'yyyy-mm-dd') {
				  return isTime? _year + '-' + _month + '-' + _day + ' ' + _hours + ':' + _minutes + ':' + _seconds : _year + '-' + _month + '-' + _day
				  //return _year + '-' + _month + '-' + _day
				} else {
				  return ''
				}
			}
		};

		/**
		 * 初始化插件的函数
		 */
		function initZhiziHelper() {
			if (typeof (jQuery) == "undefined") {
				console.log("等待JQ加载");
				setTimeout(initZhiziHelper, 500);
			} else {
				//强制升级程序，此newVersion一定要跟 main_public.user.js 里的version一致
				//如果可以读取 main_public.user.js 里面的参数，放入这，那么升级就一定会一致
				// var newVersion = "0.4.6";
				console.log('本来更新的逻辑');
				// if (ZhiziWebsite.version != newVersion) {
				// 	ZhiziCommon.openMask();
				// 	ZhiziCommon.setMaskTitle('请点击浏览器右上角油猴按钮，并选择用户脚本检查更新,弹出界面后，点击更新');
				// 	ZhiziCommon.setMaskBody('无法按照上诉更新的<a href="http://jsurl.tongtaoms.com/tampermonkey/readme.html" target="_blank">点此跳转</a>重新安装/更新');
				// 	ZhiziCommon.setMaskFoot('当前版本' + ZhiziWebsite.version + '，最新版本为:' + newVersion);
				// 	ZhiziCommon.showCloseBtn();
				// 	return;
				// }	
			}
			//初始化 toolbar的框架按钮
			// ZhiziCommon.toolbar();
			//再toolbar的框架里面，初始化需要的按钮
			ZhiziCommon.initPlugins();
		}

		/**
		 * 加载脚本后，首先调用此函数
		 */
		initZhiziHelper();

		unsafeWindow.ZhiziCommon = ZhiziCommon;
	}
}
