/**
 *  时间工具类
 */
{
    init: function () {
        var zhiziDataUtil = {
            reportType: "",
            /**
             * 获取前多少天，传入n=1，可以得到 昨天 日期，
             * 例如，
             *    今日"2018-04-15"，通过函数：zhiziDataUtil.getBeforeDate(1)，可以得到 "2019-04-14"
             */
            getBeforeDate: function (n) {
                var n = n;
                var d = new Date();
                return zhiziDataUtil.getBeforeDateByDate(n,d);
            },
            /**
             * 根据指定时间，获取前多少天
             * @param n 前多少天
             * @param d 当前一个日期
             *  例如，
             *       n = 3,d = new Date("2019-04-30"),
             *       zhiziDataUtil.getBeforeDateByDate(3,new Date("2019-04-30"))
             *       调用上面函数后，结果为："2019-04-27"
             * @returns {string}
             */
            getBeforeDateByDate: function (n,d) {
                var n = n;
                // var d = new Date();
                var year = d.getFullYear();
                var mon = d.getMonth() + 1;
                var day = d.getDate();
                if (day <= n) {
                    if (mon > 1) {
                        mon = mon - 1;
                    } else {
                        year = year - 1;
                        mon = 12;
                    }
                }
                d.setDate(d.getDate() - n);
                year = d.getFullYear();
                mon = d.getMonth() + 1;
                day = d.getDate();
                var s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
                return s;
            },
            /**
             * 根据两个日期，判断相差天数
             * @param sDate1 开始日期 如：2016-11-01
             * @param sDate2 结束日期 如：2016-11-02
             * @returns {number} 返回相差天数
             */
            daysBetween: function (sDate1, sDate2) {
                //Date.parse() 解析一个日期时间字符串，并返回1970/1/1 午夜距离该日期时间的毫秒数
                var time1 = Date.parse(new Date(sDate1));
                var time2 = Date.parse(new Date(sDate2));
                var nDays = parseInt((time2 - time1) / 1000 / 3600 / 24);
                // var nDays = Math.abs(parseInt((time2 - time1) / 1000 / 3600 / 24));
                return nDays;
            },
            /**
             * 使用案例：dateFtt("MM-yyyy-dd hh:mm:ss",new Date("2019-04-29"))
             * @param fmt  yyyy-MM-dd hh:mm:ss 格式化时间样板
             * @param date new Date();
             * @returns {*} 根据fmt脚本，格式化
             */
            dateFmt:function(fmt,date){
                var o = {
                    "M+" : date.getMonth()+1,                 //月份
                    "d+" : date.getDate(),                    //日
                    "h+" : date.getHours(),                   //小时
                    "m+" : date.getMinutes(),                 //分
                    "s+" : date.getSeconds(),                 //秒
                    "q+" : Math.floor((date.getMonth()+3)/3), //季度
                    "S"  : date.getMilliseconds()             //毫秒
                };
                if(/(y+)/.test(fmt))
                    fmt=fmt.replace(RegExp.$1, (date.getFullYear()+"").substr(4 - RegExp.$1.length));
                for(var k in o)
                    if(new RegExp("("+ k +")").test(fmt))
                        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
                return fmt;
            },
            /**
             * 休息一段时间，有时候访问amazon太快，需要将访问速度放慢
             * @param n表示的毫秒数
             */
            sleep:function(n) { 
                var start = new Date().getTime();
                while (true) if (new Date().getTime() - start > n) break;
            }
        };
        unsafeWindow.zhiziDataUtil = zhiziDataUtil;
    }
}