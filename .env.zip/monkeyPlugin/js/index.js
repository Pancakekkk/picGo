// ==UserScript==
// @name		 博创ERP智能脚本
// @namespace	bcerp
// @version	  0.4.6
// @description  xx
// @match		https://sellercentral.amazon.com/*
// @match		https://sellercentral.amazon.ca/*
// @match		https://sellercentral.amazon.co.uk/*
// @match		https://sellercentral.amazon.de/*
// @match		https://sellercentral.amazon.fr/*
// @match		https://sellercentral.amazon.it/*
// @match		https://sellercentral.amazon.es/*
// @match		https://sellercentral.amazon.co.jp/*
// @match		https://sellercentral-europe.amazon.com/*
// @match		https://sellercentral-japan.amazon.com/*
// @match		https://sellercentral.amazon.com.au/*
// @match		https://sellercentral.amazon.in/*
// @match		https://sellercentral.amazon.ae/*
// @match		https://sellercentral.amazon.com.mx/*
// @match		https://sellercentral.amazon.sg/*
// @match		https://sellercentral.amazon.nl/*
// @match		https://sellercentral.amazon.com.br/*
// @match		https://sellercentral.amazon.sa/*
// @match		https://sellercentral.amazon.tr/*
// @match		https://sellercentral.amazon.pl/*

// @match		https://advertising.amazon.ca/*
// @match		https://advertising.amazon.com/*
// @match		https://advertising.amazon.co.uk/*
// @match		https://advertising.amazon.de/*
// @match		https://advertising.amazon.fr/*
// @match		https://advertising.amazon.it/*
// @match		https://advertising.amazon.es/*
// @match		https://advertising-japan.amazon.com/*
// @match		https://advertising.amazon.co.jp/*
// @match		https://advertising.amazon.com.mx/*
// @match		https://advertising.amazon.com.au/*
// @match		https://advertising.amazon.ae/*
// @match		https://advertising.amazon.in/*
// @match		https://advertising.amazon.sa/*
// @match		https://advertising.amazon.nl/*
// @match		https://advertising.amazon.sg/*
// @match		https://advertising.amazon.com.br/*
// @resource    easyui https://erp.wandinghui.com/monkey/js/plugins/easyui.css?v=456

// @grant		GM_xmlhttpRequest
// @grant		GM_addStyle
// @grant		GM_download
// @grant		GM_listValues
// @grant		GM_setValue
// @grant		GM_getValue
// @grant       GM_getResourceText
// @grant		GM_deleteValue
// @grant		GM_log
// @grant		GM_addValueChangeListener
// @grant		GM_registerMenuCommand
// @grant		GM_openInTab
// @grant		GM_notification

// @noframes
// @grant		unsafeWindow
// @connect	  127.0.0.1
// @connect	  erp.wandinghui.com
// @connect	  *
// ==/UserScript==

/**
 * 开发注意事项：
 * 1. 使用tab, 不要tab自动转空格
 */

(function () {
  'use strict'
  console.log('---进入脚本---')
  var ZhiziWebsite = {
    random: Math.round(Math.random() * 1000),
    jsUrl: 'https://erp.wandinghui.com/monkey',
    apiUrl: 'http://127.0.0.1',
    version: GM_info.script.version
  }
  var easyui = GM_getResourceText('easyui')
  GM_addStyle(easyui)
  // main函数主入口
  var ZhiziMain = {
    getScript: function (url) {
      var startTime = new Date()
      console.log('开始加载脚本:' + url)
      ZhiziMain.GMGet(url, function (res) {
        var obj = eval('(' + res.responseText + ')')
        obj.init()
        var endTime = new Date()
        var result = endTime.getTime() - startTime.getTime()
        console.log('脚本加载完成，耗时:' + result + 'ms')
      }, function (res) {
        setTimeout(function () {
          ZhiziMain.getScript(url)
        }, 1000)
      })
    },
    initCommon: function () {
      var commonUrl = ZhiziWebsite.jsUrl + '/js/amazon/zhizi_common.js?v=' + ZhiziWebsite.random
      ZhiziMain.getScript(commonUrl)
    },
    GMGet: function (url, successCallback, errorCallback) {
      GM_xmlhttpRequest({
        method: 'get',
        url: url,
        onload: function (res) {
          if (res.status == 200) {
            successCallback(res)
          } else {
            errorCallback(res)
          }
        },
        onerror: function (res) {
          errorCallback(res)
        }
      })
    }
  }
  function initMain(initJQ) {
    console.log('博创智光ERP-智能插件-正在初始化 ...')
    var version = GM_info.script.version
    if (typeof (jQuery) === 'undefined') {
      console.log('JQ尚未加载, 请求加载JQ: ' + initJQ)
      if (initJQ) {
        var jqUrl = ZhiziWebsite.jsUrl + '/js/plugins/jquery-3.1.1.min.js?v=' + version
        ZhiziMain.getScript(jqUrl)
        initJQ = false
      }
      setTimeout(function () {
        initMain(initJQ)
      }, 1000)
    } else {
      console.log('JQ已经加载 ...')
      ZhiziMain.initCommon()
    }
  }
  if (window.location.href.indexOf('/cm/campaigns') != -1 || window.location.href.indexOf('/sp/campaigns') != -1) {
    // 针对各别的网址，需要后等界面加载后，再进行插件的加载
    var flag = true
    window.onload = function (ev) {
      if (flag) {
        flag = false
        initMain(true)
      }
    }
    // 10秒后自动检测一下，是否真的执行了window.location
    setTimeout(function () {
      console.log('是否setTimeout执行的结果？' + flag)
      if (flag) {
        flag = false
        initMain(true)
      }
    }, 10 * 1000)
  } else {
    initMain(true)
  }

  unsafeWindow.ZhiziWebsite = ZhiziWebsite
})()
