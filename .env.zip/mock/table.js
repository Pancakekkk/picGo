const Mock = require('mockjs')

// 商品类别列表
const data = Mock.mock({
  'items|30': [{
    id: '@id',
    title: 'title1',
    author: '@name',
    creater: '@name',
    display_time: '@datetime',
    'status|1': ['on', 'off'],
    checked: false,
    parent: null
  }]
})
// 商品信息列表
const goodsInfoData = Mock.mock({
  'items|30': [{
    id: '@id',
    code: 'CP-TD-009-001',
    type: '@name',
    goodsName: 'title2',
    picUrl: 'https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg',
    model: '@name',
    typeSize: '@name',
    weight: '@name',
    price: '@name',
    info: '@name'
  }]
})
// 商品信息详情
const goodsInfoDatail = Mock.mock({
  'items': {
    id: '@id',
    code: 'CP-TD-009-002',
    type: '@name',
    goodsName: 'title3',
    picUrl: '',
    model: '@name',
    typeSize: '@name',
    weight: '@name',
    price: '@name',
    info: '@name',
    unit: '@name',
    length: '@name',
    width: '@name',
    height: '@name',
    customsCnName: '@name',
    customsEnName: '@name',
    packageQuantity: '@name',
    packageWeight: '@name',
    packageLength: '@name',
    packageWidth: '@name',
    packageHeight: '@name'
  }
})
// 商品Bom列表
const goodsBomData = Mock.mock({
  'items|30': [{
    id: '@id',
    productCode: 'CP-TD-009-003',
    categoryId: '@name',
    productName: '@name',
    imageUrls: '',
    productBomCode: '@name',
    createUserId: '@name',
    createTime: '@datetime',
    updateUserId: '@name',
    updateTime: '@datetime'
  }]
})
// 服务平台分页
const servicePlatform = Mock.mock({
  'items|30': [{
    id: '@id',
    name: '@name',
    currency: 'yizhi',
    fee: '@name',
    currencyRate: '@name',
    remark: '@name',
    createUserId: '@name',
    createTime: '@datetime'
  }]
})
// 服务类型分页
const serviceType = Mock.mock({
  'items|30': [{
    id: '@id',
    name: '@name',
    enName: '@name',
    remark: '@name',
    status: 'yizhi',
    createUserId: '@name',
    createTime: '@datetime'
  }]
})
// 币种汇率分页
const currencyRate = Mock.mock({
  'items|30': [{
    id: '@id',
    exchangeTime: '@date',
    name: '@name',
    shortName: '@name',
    rate: '@name',
    createUserId: '@name',
    createTime: '@datetime'
  }]
})
// 店铺管理分页
const shopData = Mock.mock({
  'items|30': [{
    id: '@id',
    platformName: '@date',
    shopName: '@name',
    status: 'yizhi',
    siteName: '@name',
    userName: '@name',
    organName: '@name',
    createUserId: '@name',
    createTime: '@datetime'
  }]
})
// 国家区域分页
const countryAreaData = Mock.mock({
  'items|30': [{
    id: '@id',
    cnName: '@date',
    enName: '@name',
    shortCode: 'yizhi',
    continent: '@name',
    createUserId: '@name',
    createTime: '@datetime'
  }]
})
// 订单列表分页
const orderData = Mock.mock({
  'items|30': [{
    id: '@id',
    orderId: '@id',
    purchaseDate: '@date',
    orderStatus: '@name',
    isEvaluate: '@name',
    imageUrls: '',
    totalAmount: '@name'
  }]
})
// 营销看板
const marketInfo = Mock.mock({
  'items': {
    amountSum: '2325900',
    saleAmountSum: '12253259.66',
    grossProfitSum: '2153259.66',
    amount: '2325900',
    saleAmount: '2325900',
    grossProfit: '2325900',
    picUrl: '',
    model: '@name',
    typeSize: '@name',
    weight: '@name',
    price: '@name',
    info: '@name',
    unit: '@name',
    length: '@name',
    width: '@name',
    height: '@name',
    customsCnName: '@name',
    customsEnName: '@name',
    packageQuantity: '@name',
    packageWeight: '@name',
    packageLength: '@name',
    packageWidth: '@name',
    packageHeight: '@name',
    saleData: [{
      saleDate: '2020-04-21',
      saleCount: '1234',
      saleAmount: '56789',
      grossProft: '1011'
    }]
  }
})

module.exports = [
  {
    url: '/table/list',
    type: 'get',
    response: config => {
      const items = data.items
      items[0].children = [{
        id: 315,
        title: '2016-05-01',
        author: '王小虎',
        creater: '王小虎',
        display_time: '王小虎',
        status: 'on',
        checked: false,
        parent: null,
        children: [
          {
            id: 325,
            title: '2016',
            author: '王小',
            creater: '王小',
            display_time: '王小',
            status: 'off',
            checked: false,
            parent: null
          }
        ]
      }]
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/goodsInfo/list',
    type: 'get',
    response: config => {
      const items = goodsInfoData.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/goodsInfo/goodsInfoDetail',
    type: 'get',
    response: config => {
      const items = goodsInfoDatail.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/goodsBom/list',
    type: 'get',
    response: config => {
      const items = goodsBomData.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/mock/servicePlatform/list',
    type: 'get',
    response: config => {
      const items = servicePlatform.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/serviceType/list',
    type: 'get',
    response: config => {
      const items = serviceType.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/currencyRate/list',
    type: 'get',
    response: config => {
      const items = currencyRate.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/shop/list',
    type: 'get',
    response: config => {
      const items = shopData.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/countryArea/list',
    type: 'get',
    response: config => {
      const items = countryAreaData.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/order/list',
    type: 'get',
    response: config => {
      const items = orderData.items
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/market/info',
    type: 'get',
    response: config => {
      const items = marketInfo.items
      // 销售额 折线图
      items.saleAmountSummary = {
        summaryCount: 1376.15,
        dataLst: [
          {
            'name': '销售额',
            'value': null,
            'data': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 52.4, 0.0, 0.0, 0.0, 15.0, 0.0, 0.0, 893.89, 0.0, 107.5, 7.43, 0.0]
          },
          {
            'name': '毛利润',
            'value': null,
            'data': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 179.8, 0.0, 0.0]
          },
          {
            'name': '销量',
            'value': null,
            'data': [6.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 112.0, 0.0, 0.0, 179.8, 0.0, 0.0]
          }],
        xaxisLst: ['18011', '18012', '1901', '1902', '1903', '1904', '1905', '1906', '1907', '1908', '1909', '19010', '19011', '19012', '01', '02', '03', '04', '05']
      }
      // 店铺分析 柱状图
      items.shopBarData = {
        dimensions: ['店铺', '销售额', '毛利润', '销量'],
        source: [
          ['恒生UK', 18000, 6000, 200],
          ['恒升DE', 28000, 22000, 300],
          ['东莞博创US', 13000, 10000, 400],
          ['武汉鑫隆CA', 26000, 25000, 555],
          ['成方圆CA', 65000, 58000, 100],
          ['恒升CA', 8000, 5000, 55]
        ]
      }
      // 店铺分析 饼状图
      items.shopPieData = {
        name: '销售额',
        data: [
          { value: 18000, name: '恒生UK' },
          { value: 28000, name: '恒升DE' },
          { value: 13000, name: '东莞博创US' },
          { value: 36000, name: '武汉鑫隆CA' },
          { value: 65000, name: '成方圆CA' },
          { value: 8000, name: '恒升CA' }
        ]
      }
      // 商品分析 柱状图
      items.productBarData = {
        dimensions: ['店铺', '销售额'],
        source: [
          ['恒生UK', 18000],
          ['恒升DE', 28000],
          ['东莞博创US', 13000],
          ['武汉鑫隆CA', 26000],
          ['成方圆CA', 65000],
          ['恒升CA', 8000]
        ]
      }
      // 商品分析 饼状图
      items.productPieData = {
        name: '销售额',
        data: [
          { value: 18000, name: '恒生UK' },
          { value: 28000, name: '恒升DE' },
          { value: 13000, name: '东莞博创US' },
          { value: 36000, name: '武汉鑫隆CA' },
          { value: 65000, name: '成方圆CA' },
          { value: 8000, name: '恒升CA' }
        ]
      }
      // 部门分析 柱状图
      items.organBarData = {
        pid: -1,
        dimensions: ['部门', '销售额'],
        source: [
          ['博创办公室', 18000],
          ['资源管理中心', 28000],
          ['人事部', 38000]
        ],
        children: [{
          pid: 2,
          dimensions: ['部门', '销售额'],
          source: [
            ['财务部', 8000],
            ['项目部', 2000],
            ['生产部', 13000],
            ['业务部', 6000]
          ],
          children: [{
            pid: 11,
            dimensions: ['部门', '销售额'],
            source: [
              ['财务部', 8000]
            ],
            children: []
          }, {
            pid: 13,
            dimensions: ['部门', '销售额'],
            source: [
              ['项目部', 2000]
            ],
            children: []
          }, {
            pid: 17,
            dimensions: ['部门', '销售额'],
            source: [
              ['生产部', 13000]
            ],
            children: []
          }, {
            pid: 18,
            dimensions: ['部门', '销售额'],
            source: [
              ['业务部', 6000]
            ],
            children: []
          }]
        }, {
          pid: 15,
          dimensions: ['部门', '销售额'],
          source: [
            ['仓库', 8000]
          ],
          children: []
        }, {
          pid: 20,
          dimensions: ['部门', '销售额'],
          source: [],
          children: []
        }]
      }
      // 商品分类分析 柱状图
      items.productTypeBarData = {
        dimensions: ['商品分类', '销售额'],
        source: [
          ['灯泡A1', 18000],
          ['灯泡A2', 28000],
          ['灯泡A3', 13000],
          ['灯泡A4', 26000]
        ]
      }
      return {
        state: 0,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/goods/type',
    type: 'get',
    response: config => {
      const options = [{
        value: 'zhinan',
        label: '指南',
        children: [{
          value: 'shejiyuanze',
          label: '设计原则',
          children: [{
            value: 'yizhi',
            label: '一致'
          }, {
            value: 'fankui',
            label: '反馈'
          }, {
            value: 'xiaolv',
            label: '效率'
          }, {
            value: 'kekong',
            label: '可控'
          }]
        }, {
          value: 'daohang',
          label: '导航',
          children: [{
            value: 'cexiangdaohang',
            label: '侧向导航'
          }, {
            value: 'dingbudaohang',
            label: '顶部导航'
          }]
        }]
      }, {
        value: 'ziyuan',
        label: '资源',
        children: [{
          value: 'axure',
          label: 'Axure Components'
        }, {
          value: 'sketch',
          label: 'Sketch Templates'
        }, {
          value: 'jiaohu',
          label: '组件交互文档'
        }]
      }]
      return {
        state: 0,
        data: {
          options: options
        }
      }
    }
  }
]
