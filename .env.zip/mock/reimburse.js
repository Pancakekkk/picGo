const { Random } = require('mockjs')
const Mock = require('mockjs')

// 销售分析-总体销售情况
const salesSummaryInfo = Mock.mock({
  'records|100': [
    {
      'shopName': '康德隆-US',
      'saleQuantity': '@integer(0, 1000)',
      'saleAmount': '@float(0, 99999999, 2, 2)',
      'actualSaleAmount': '@float(0, 99999999, 2, 2)',
      'grossProfitRmb': '@float(0, 99999999, 2, 2)',
      'couponHandlingFee': '@float(0, 99999999, 2, 2)',
      'otherFeesRmb': '@float(0, 99999999, 2, 2)',
      'warehouseCostRmb': '@float(0, 99999999, 2, 2)',
      'actualGrossProfitRmb': '@float(0, 99999999, 2, 2)',
      'rejectQuantity': '@integer(0, 1000)',
      'refundAmountRmb': '@float(0, 99999999, 2, 2)',
      'rejectCostRmb': '@float(0, 99999999, 2, 2)',
      'rejectRate': '@float(0, 99, 2, 2)',
      'advertiseAmountRmb': '@float(0, 99999999, 2, 2)',
      'advertiseSaleAmountRmb': '@float(0, 99999999, 2, 2)',
      'advertiseACoS': '@float(0, 99, 2, 2)',
      'advertiseSaleRate': '@float(0, 99, 2, 2)',
      'evaluateQuantity': '@integer(0, 1000)',
      'evaluateFeeRmb': '@float(0, 99999999, 2, 2)'
    }
  ]
})

// 销售分析-单个店铺销售情况-本期
const salesShopInfoCurrent = Mock.mock({
  'typeName': '本期',
  'saleQuantity': '@integer(0, 1000)',
  'saleAmount': '@float(0, 99999999, 2, 2)',
  'actualSaleAmount': '@float(0, 99999999, 2, 2)',
  'grossProfitRmb': '@float(0, 99999999, 2, 2)',
  'couponHandlingFee': '@float(0, 99999999, 2, 2)',
  'otherFeesRmb': '@float(0, 99999999, 2, 2)',
  'warehouseCostRmb': '@float(0, 99999999, 2, 2)',
  'actualGrossProfitRmb': '@float(0, 99999999, 2, 2)',
  'rejectQuantity': '@integer(0, 1000)',
  'refundAmountRmb': '@float(0, 99999999, 2, 2)',
  'rejectCostRmb': '@float(0, 99999999, 2, 2)',
  'rejectRate': '@float(0, 99, 2, 2)',
  'advertiseAmountRmb': '@float(0, 99999999, 2, 2)',
  'advertiseSaleAmountRmb': '@float(0, 99999999, 2, 2)',
  'advertiseACoS': '@float(0, 99, 2, 2)',
  'advertiseSaleRate': '@float(0, 99, 2, 2)',
  'evaluateQuantity': '@integer(0, 1000)',
  'evaluateFeeRmb': '@float(0, 99999999, 2, 2)'
})

// 销售分析-单个店铺销售情况-上期
const salesShopInfoLast = Mock.mock({
  'typeName': '上期',
  'saleQuantity': '@integer(0, 1000)',
  'saleAmount': '@float(0, 99999999, 2, 2)',
  'actualSaleAmount': '@float(0, 99999999, 2, 2)',
  'grossProfitRmb': '@float(0, 99999999, 2, 2)',
  'couponHandlingFee': '@float(0, 99999999, 2, 2)',
  'otherFeesRmb': '@float(0, 99999999, 2, 2)',
  'warehouseCostRmb': '@float(0, 99999999, 2, 2)',
  'actualGrossProfitRmb': '@float(0, 99999999, 2, 2)',
  'rejectQuantity': '@integer(0, 1000)',
  'refundAmountRmb': '@float(0, 99999999, 2, 2)',
  'rejectCostRmb': '@float(0, 99999999, 2, 2)',
  'rejectRate': '@float(0, 99, 2, 2)',
  'advertiseAmountRmb': '@float(0, 99999999, 2, 2)',
  'advertiseSaleAmountRmb': '@float(0, 99999999, 2, 2)',
  'advertiseACoS': '@float(0, 99, 2, 2)',
  'advertiseSaleRate': '@float(0, 99, 2, 2)',
  'evaluateQuantity': '@integer(0, 1000)',
  'evaluateFeeRmb': '@float(0, 99999999, 2, 2)'
})

// 销售分析-单个店铺销售情况-环比
const salesShopInfoQOQ = Mock.mock({
  'typeName': '环比(%)',
  'saleQuantity': '@float(0, 99, 2, 2)',
  'saleAmount': '@float(0, 99, 2, 2)',
  'actualSaleAmount': '@float(0, 99, 2, 2)',
  'grossProfitRmb': '@float(0, 99, 2, 2)',
  'couponHandlingFee': '@float(0, 99, 2, 2)',
  'otherFeesRmb': '@float(0, 99, 2, 2)',
  'warehouseCostRmb': '@float(0, 99, 2, 2)',
  'actualGrossProfitRmb': '@float(0, 99, 2, 2)',
  'rejectQuantity': '@float(0, 99, 2, 2)',
  'refundAmountRmb': '@float(0, 99, 2, 2)',
  'rejectCostRmb': '@float(0, 99, 2, 2)',
  'rejectRate': '',
  'advertiseAmountRmb': '@float(0, 99, 2, 2)',
  'advertiseSaleAmountRmb': '@float(0, 99, 2, 2)',
  'advertiseACoS': '',
  'advertiseSaleRate': '',
  'evaluateQuantity': '@float(0, 99, 2, 2)',
  'evaluateFeeRmb': '@float(0, 99, 2, 2)'
})

const salesSkuProfitList = Mock.mock({
  'records|100': [
    {
      startDate: '2021-04-19',
      endDate: '2021-04-25',
      'productSku': '@string("upper", 2)-' + '@string(2, 5)-' + '@string(2, 3)-' + '@string(2, 4)',
      'productCode': '@string(8)',
      'productName': '@cword(10)',
      'userName': '@cname',
      'shopName|1': [
        '康德隆-US',
        '康德隆-CA',
        '恒升-US',
        '恒升-CA'
      ],
      'siteName|1': [
        'US',
        'CA'
      ],
      'currencyRate': '@float(0, 11, 0, 4)',
      'salesVolume': '@integer(0, 1000)',
      'avgPrice': '@float(0, 99999999, 2, 2)' + ' USD',
      'avgPriceRMB': '@float(0, 99999999, 2, 2)',
      'salesAmount': '@float(0, 99999999, 2, 2)' + ' USD',
      'salesAmountRMB': '@float(0, 99999999, 2, 2)',
      'costFeesSumRMB': '@float(0, 99999999, 2, 2)',
      'profitSumRMB': '@float(0, 99999999, 2, 2)',
      'profitRate': '@float(0, 99, 2, 2)',
      'purchaseCostRMB': '@float(0, 99999999, 2, 2)',
      'firstShippingPriceRMB': '@float(0, 99999999, 2, 2)',
      'sellingFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'sellingFeesRMB': '@float(0, 99999999, 2, 2)',
      'fbaFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'fbaFeesRMB': '@float(0, 99999999, 2, 2)',
      'lastShippingPrice': '@float(0, 99999999, 2, 2)' + ' USD',
      'lastShippingPriceRMB': '@float(0, 99999999, 2, 2)',
      'advertiseFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'advertiseFeesRMB': '@float(0, 99999999, 2, 2)',
      'evaluateFeesRMB': '@float(0, 99999999, 2, 2)',
      'refundAmount': '@float(0, 99999999, 2, 2)' + ' USD',
      'refundAmountRMB': '@float(0, 99999999, 2, 2)',
      'inventoryFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'inventoryFeesRMB': '@float(0, 99999999, 2, 2)',
      'otherFeesRMB': '@float(0, 99999999, 2, 2)',
      'refundQuantity': '@integer(0, 1000)'
    }
  ]
})

const skuProfitList = Mock.mock({
  'records|100': [
    {
      startDate: '2021-04-19',
      endDate: '2021-04-25',
      'productSku': '@string("upper", 2)-' + '@string(2, 5)-' + '@string(2, 3)-' + '@string(2, 4)',
      // 'productSku': Random.string('upper', 2) + '-' + Random.string(2, 5) + '-' + Random.string(2, 3) + '-' + Random.string(2, 4),
      'productCode': '@string(8)',
      'productName': '@cword(10)',
      'userName': '@cname',
      'shopName|1': [
        '康德隆-US',
        '康德隆-CA',
        '恒升-US',
        '恒升-CA'
      ],
      'siteName|1': [
        'US',
        'CA'
      ],
      'currencyRate': '@float(0, 11, 0, 4)',
      'salesVolume': '@integer(0, 1000)',
      'avgPrice': '@float(0, 99999999, 2, 2)' + ' USD',
      'avgPriceRMB': '@float(0, 99999999, 2, 2)',
      'salesAmount': '@float(0, 99999999, 2, 2)' + ' USD',
      'salesAmountRMB': '@float(0, 99999999, 2, 2)',
      'costFeesSumRMB': '@float(0, 99999999, 2, 2)',
      'profitSumRMB': '@float(0, 99999999, 2, 2)',
      'profitRate': '@float(0, 99, 2, 2)',
      'purchaseCostRMB': '@float(0, 99999999, 2, 2)',
      'firstShippingPriceRMB': '@float(0, 99999999, 2, 2)',
      'sellingFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'sellingFeesRMB': '@float(0, 99999999, 2, 2)',
      'fbaFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'fbaFeesRMB': '@float(0, 99999999, 2, 2)',
      'lastShippingPrice': '@float(0, 99999999, 2, 2)' + ' USD',
      'lastShippingPriceRMB': '@float(0, 99999999, 2, 2)',
      'advertiseFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'advertiseFeesRMB': '@float(0, 99999999, 2, 2)',
      'evaluateFeesRMB': '@float(0, 99999999, 2, 2)',
      'refundAmount': '@float(0, 99999999, 2, 2)' + ' USD',
      'refundAmountRMB': '@float(0, 99999999, 2, 2)',
      'inventoryFees': '@float(0, 99999999, 2, 2)' + ' USD',
      'inventoryFeesRMB': '@float(0, 99999999, 2, 2)',
      'otherFeesRMB': '@float(0, 99999999, 2, 2)',
      'refundQuantity': '@integer(0, 1000)'
    }
  ]
})

const notifyList = []
for (let i = 100; i > 0; i--) {
  notifyList.push({
    id: i,
    title: '您有一条报销流程核查异常，请及时跟进查看处理！',
    content: '您发起的关于订单号为' + i + '的报销流程核查异常，请及时跟进查看处理',
    time: '2021-04-29 11:12:00',
    new: i > 90
  })
}

module.exports = [
  {
    url: '/mock/bcerp-sale/summaryInfo', // 销售分析-总体销售情况
    type: 'post',
    response: config => {
      const size = config.body.pageSize
      const num = config.body.pageNum
      const start = (num - 1) * size + 1
      const records = salesSummaryInfo.records
      const filterRecord = records.slice(start, start + size)
      return {
        state: 0,
        data: {
          total: records.length,
          size: size,
          records: filterRecord,
          params: config.body
        }
      }
    }
  },
  {
    url: '/mock/bcerp-sale/shopInfo', // 销售分析-单个店铺销售情况
    type: 'post',
    response: config => {
      return {
        state: 0,
        data: {
          cRecords: salesShopInfoCurrent,
          lRecords: salesShopInfoLast,
          qRecords: salesShopInfoQOQ,
          params: config.body
        }
      }
    }
  },
  {
    url: '/mock/bcerp-sale/shopSkuInfo', // 销售分析-店铺SKU销售情况
    type: 'post',
    response: config => {
      const size = config.body.pageSize
      const num = config.body.pageNum
      const start = (num - 1) * size + 1
      const records = salesSkuProfitList.records
      const filterRecord = records.slice(start, start + size)
      return {
        state: 0,
        data: {
          total: records.length,
          size: size,
          records: filterRecord,
          params: config.body
        }
      }
    }
  },
  {
    url: '/mock/bcerp-sale/skuProfitList', // SKU利润核算
    type: 'post',
    response: config => {
      const size = config.body.pageSize
      const num = config.body.pageNum
      const start = (num - 1) * size + 1
      const records = skuProfitList.records
      const filterRecord = records.slice(start, start + size)
      return {
        state: 0,
        data: {
          total: records.length,
          size: size,
          records: filterRecord,
          params: config.body
        }
      }
    }
  },
  {
    url: '/order/getInfo',
    type: 'get',
    response: config => {
      let result = {}
      if (config.query.id !== 0) {
        result = {
          orderId: '111-2222222-3333333',
          sku: 'SK-ISUN-WHIN-SH',
          orderStatus: '已完成',
          shop: '1',
          site: 'US',
          orderPriceCurrency: 'USD',
          orderPrice: 20,
          checkCost: 25,
          realCost: 0
        }
      }
      return {
        code: 20000,
        data: result
      }
    }
  },
  {
    url: '/servicePlatform/getInfo',
    type: 'get',
    response: config => {
      let result = {}
      if (config.query.id) {
        // 服务平台信息
        const servicePlatformInfo = Mock.mock({
          'items|1': [
            {
              'exchangeRate|6-7.2-2': 1,
              'serviceFee|1-10.2-2': 1,
              'serviceFeeCurrency|1': ['RMB', 'RMB', 'RMB', 'RMB', 'USD']
            }
          ]
        })
        result = servicePlatformInfo.items
        result.servicePlatformId = config.query.id
      }
      return {
        code: 20000,
        data: result
      }
    }
  },
  {
    url: '/reimburse/commitFlow',
    type: 'post',
    response: config => {
      return {
        code: 20000,
        data: {
          nextDataId: 8054,
          nextProcessNum: '20210221001',
          nextProcessStatus: 1,
          nextProcessTitle: '测试申请_入库申请',
          nextSubType: 6,
          nextType: 20,
          processStatus: 4,
          sendEmailErr: null
        },
        msg: ''
      }
    }
  },
  {
    url: '/bcerp-sale/notify',
    type: 'post',
    response: config => {
      const start = config.body.start
      const length = config.body.length
      const list = notifyList.slice(start, start + length)
      const newNotifyList = notifyList.filter((value) => {
        return value.new
      })
      return {
        code: 20000,
        data: {
          newMessageCount: newNotifyList.length,
          messageLst: list,
          param: config.body
        },
        msg: ''
      }
    }
  },
  {
    url: '/bcerp-sale/updateNotifyStatus',
    type: 'post',
    response: config => {
      const id = config.body.id
      for (const n of notifyList) {
        if (n.id === id || id === -1) {
          n.new = false
        }
      }
      const newNotifyList = notifyList.filter((value) => {
        return value.new
      })
      return {
        code: 20000,
        data: newNotifyList.length,
        msg: '更新成功'
      }
    }
  },
  {
    url: '/bcerp-sale/getQuickMenuList',
    type: 'post',
    response: config => {
      return {
        state: 0,
        data: [],
        msg: ''
      }
    }
  },
  {
    url: '/bcerp-sale/getQuickMenuSettingsList',
    type: 'post',
    response: config => {
      return {
        state: 0,
        data: [],
        msg: ''
      }
    }
  },
  {
    url: '/bcerp-sale/saveQuickMenuSettings',
    type: 'post',
    response: config => {
      return {
        state: 0,
        data: [],
        msg: ''
      }
    }
  }
]
